<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ABP extends CI_Controller
{
  public function __construct()
  {
    parent::__construct();
    is_logged_in();

    if($this->session->userdata('role_id') != 2){
        redirect();
     }

    $this->load->model('M_ABP');
    $this->load->library('upload');
    $this->load->model('M_utility');
  }

  public function index()
  {
    $data_get = 'id, nama, nik, alamat, tgl_periksa, status_pemeriksaan';
    $formpc_menunggu_valid = $this->M_utility->get_data($data_get, 'formpc', ['status_pemeriksaan' => 'Tahap Validasi']);
    $data['formpc_list'] = $formpc_menunggu_valid->result();
    $data['formpc'] = $formpc_menunggu_valid->num_rows();
    $data['formpc_valid'] = $this->M_utility->get_data($data_get, 'formpc', ['status_pemeriksaan' => 'Menunggu verifikasi'])->num_rows();
    $data['formpc_ditangguhkan'] = $this->M_utility->get_data($data_get, 'formpc', ['status_pemeriksaan' => 'Ditangguhkan'])->num_rows();

    $data['sidebar']  = 'dashboard';
    $data['title'] = 'Home Asisten Bidang Perencanaan';
    $data['user'] = $this->db->get_where('user', ['email' =>
    $this->session->userdata('email')])->row_array();
    $this->load->view('templates/header', $data);
    $this->load->view('templates/abp_sidebar', $data);
    $this->load->view('templates/topbar', $data);
    $this->load->view('ABP/index', $data);
    $this->load->view('templates/footer');
  }

  public function profile()
  {
    $data['title'] = 'Halaman Profile';
    $data['subtitle'] = 'Profile';
    $data['user'] = $this->db->get_where('user', ['email' =>
    $this->session->userdata('email')])->row_array();
    $this->load->view('templates/header', $data);
    $this->load->view('templates/abp_sidebar', $data);
    $this->load->view('templates/topbar', $data);
    $this->load->view('ABP/profile', $data);
    $this->load->view('templates/footer');
  }

  public function formpc()
 {
   //															(Name , Alias atau nama lain)
   $this->form_validation->set_rules('nik', 'NIK', 'required|trim|numeric|integer|min_length[16]|is_unique[formpc.nik]', [
     'required'   => 'NIK tidak boleh kosong!',
     'numeric'    => 'NIK harus berupa angka!',
     'integer'    => 'NIK hanya berupa bilangan bulat!',
     'min_length' => 'NIK harus berjumlah 16 angka!',
     'is_unique'  => 'NIK sudah terdaftar!'
   ]);
   $this->form_validation->set_rules('nokk', 'NOKK', 'required|trim|numeric|integer|min_length[16]', [
     'required'   => 'No KK tidak boleh kosong!',
     'integer'    => 'No KK hanya berupa bilangan bulat!',
     'min_length' => 'No KK harus berjumlah 16 angka!',
     'numeric'    => 'No KK harus berupa angka!'
   ]);
   $this->form_validation->set_rules('nama', 'Nama', 'required|trim',[
     'required'   => 'Nama tidak boleh kosong!',
   ]);
   $this->form_validation->set_rules('tgl_lahir', 'tgl_lahir', 'required|trim',[
     'required'   => 'Tanggal lahir tidak boleh kosong!',
   ]);
   $this->form_validation->set_rules('sex', 'Sex', 'required',[
     'required'   => 'Jenis Kelamin harus dipilih!'
   ]);
   $this->form_validation->set_rules('no_hp', 'no_hp', 'required',[
     'required'   => 'No HP tidak boleh kosong!'
   ]);
   $this->form_validation->set_rules('pekerjaan', 'Pekerjaan', 'required',[
     'required'   => 'Pekerjaan tidak boleh kosong!',
   ]);
   $this->form_validation->set_rules('alamat', 'Alamat', 'required',[
     'required'   => 'Alamat tidak boleh kosong!',
   ]);
   $this->form_validation->set_rules('kelurahan', 'Kelurahan', 'required',[
     'required'   => 'Kelurahan tidak boleh kosong!',
   ]);
   $this->form_validation->set_rules('kecamatan', 'Kecamatan', 'required',[
     'required'   => 'Kecamatan tidak boleh kosong!',
   ]);
   $this->form_validation->set_rules('struktur', 'Struktur', 'required',[
     'required'   => 'Struktur tidak boleh kosong!',
   ]);
   $this->form_validation->set_rules('lokasi', 'Lokasi', 'required',[
     'required'   => 'Lokasi tidak boleh kosong!',
   ]);
   $this->form_validation->set_rules('latitude', 'Latitude', 'required',[
     'required'   => 'Latitude tidak boleh kosong!',
   ]);
   $this->form_validation->set_rules('longitude', 'Longitude', 'required',[
     'required'   => 'Struktur tidak boleh kosong!',
   ]);
   $this->form_validation->set_rules('kondisi', 'Kondisi', 'required',[
     'required'   => 'Kondisi tidak boleh kosong!',
   ]);
   $this->form_validation->set_rules('fondasi', 'Fondasi', 'required',[
     'required'   => 'Pilih salah satu skala!',
   ]);
   $this->form_validation->set_rules('dinding', 'Dinding', 'required',[
     'required'   => 'Pilih salah satu skala!',
   ]);
   $this->form_validation->set_rules('rangka', 'Rangka', 'required',[
     'required'   => 'Pilih salah satu skala!',
   ]);
   $this->form_validation->set_rules('atap', 'Atap', 'required',[
     'required'   => 'Pilih salah satu skala!',
   ]);
   $this->form_validation->set_rules('bantuan', 'Bantuan', 'required',[
     'required'   => 'Pilih salah satu kategori!',
   ]);
   $this->form_validation->set_rules('rusak', 'Rusak', 'required',[
     'required'   => 'Pilih salah satu kategori!',
   ]);
   $this->form_validation->set_rules('status', 'Status', 'required',[
     'required'   => 'Pilih salah satu kategori!',
   ]);

   $this->form_validation->set_rules('tgl_periksa', 'tgl_periksa', 'required',[
     'required'   => 'Pilih tanggal pemeriksaan!',
   ]);
   $this->form_validation->set_rules('waktu_periksa', 'waktu_periksa', 'required',[
     'required'   => 'Pilih waktu pemeriksaan!',
   ]);


    if( $this->form_validation->run() == false){
      $data['title'] = 'Halaman Form Pemeriksaan Cepat';
      $data['sidebar']  = 'form-pemeriksaan';
      $data['subtitle'] = 'Data Calon Penerima';
      $data['user'] = $this->db->get_where('user', ['email' =>
      $this->session->userdata('email')])->row_array();
      $this->load->view('templates/header', $data);
      $this->load->view('templates/abp_sidebar', $data);
      $this->load->view('templates/topbar', $data);
      $this->load->view('ABP/formpc', $data);
      $this->load->view('templates/footer');
    }
    else {

      $config['upload_path'] = './assets/img/rumah';
  		$config['allowed_types'] = 'jpg|png|jpeg';
  		$config['max_size']     = '2048';
  		$config['max_width'] = '3000';
  		$config['max_height'] = '5000';

  		$nama_file = "foto_depan".uniqid();
  		$config['file_name']=$nama_file;
  		$this->session->set_userdata('previous_page', current_url());
  		$back_to_prev_page=$this->session->userdata('previous_page');
  		$this->upload->initialize($config);
  		$this->load->library('upload', $config);
  		$this->upload->do_upload("foto");
		$gambar = $this->upload->data();

      $nama_file = "foto_samping".uniqid();
      $config['file_name']=$nama_file;
      $this->session->set_userdata('previous_page', current_url());
      $back_to_prev_page=$this->session->userdata('previous_page');
      $this->upload->initialize($config);
      $this->upload->do_upload("foto2");
     $gambar2 = $this->upload->data();


      $nama_file = "foto_belakang".uniqid();
      $config['file_name']=$nama_file;
      $this->session->set_userdata('previous_page', current_url());
      $back_to_prev_page=$this->session->userdata('previous_page');
      $this->upload->initialize($config);
      $this->upload->do_upload("foto3");
     $gambar3 = $this->upload->data();


      $this->load->library('upload', $config);
      $nama_file = "foto_kunjungan".uniqid();
      $config['file_name']=$nama_file;
      $this->session->set_userdata('previous_page', current_url());
      $back_to_prev_page=$this->session->userdata('previous_page');
      $this->upload->initialize($config);
      $this->upload->do_upload("foto_kunjungan");
     $gambar4 = $this->upload->data();


        $data = [
          'nik' => htmlspecialchars ($this->input->post('nik', true)),
          'nokk' => htmlspecialchars($this->input->post('nokk', true)),
          'nama' => htmlspecialchars ($this->input->post('nama', true)),
          'tgl_lahir' => ($this->input->post('tgl_lahir', true)),
          'sex' => $this->input->post('sex', true),
          'no_hp' => htmlspecialchars ($this->input->post('no_hp', true)),
          'pekerjaan' => htmlspecialchars($this->input->post('pekerjaan', true)),
          'alamat' => $this->input->post('alamat', true),
          'kelurahan' => $this->input->post('kelurahan', true),
          'kecamatan' => $this->input->post('kecamatan', true),
          'struktur' => $this->input->post('struktur', true),
          'lokasi' => $this->input->post('lokasi', true),
          'kondisi' => $this->input->post('kondisi', true),
          'latitude' => ($this->input->post('latitude', true)),
          'longitude' => ($this->input->post('longitude', true)),
          'fondasi' => $this->input->post('fondasi', true),
          'dinding' => $this->input->post('dinding', true),
          'rangka' => $this->input->post('rangka', true),
          'atap' => $this->input->post('atap', true),
          'bantuan' => $this->input->post('bantuan', true),
          'rusak' => $this->input->post('rusak', true),
          'status' => $this->input->post('status', true),
          'foto' => $gambar['file_name'],
          'foto2' => $gambar2['file_name'],
          'foto3' =>  $gambar3['file_name'],
          'foto_kunjungan' =>  $gambar4['file_name'],
          'nip' => htmlspecialchars ($this->input->post('nip', true)),
          'name' => htmlspecialchars($this->input->post('name', true)),
          'tgl_periksa' => ($this->input->post('tgl_periksa', true)),
          'catatan' => $this->input->post('catatan', true),
          'waktu_periksa' => ($this->input->post('waktu_periksa', true)),
        ];

      $this->M_ABP->insert($data);
      $this->session->set_flashdata('flash', 'Ditambahkan');
      redirect('ABP/daftarpc');
  }
}

  public function daftarpc()
  {
    $data['sidebar']  = 'data-pemeriksaan-cepat';
    $data['title']  = 'Halaman Daftar Calon Penerima Bantuan';
    $data['user']   = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

    $data['start'] = $this->uri->segment(3);
    $data['formpc'] = $this->M_ABP->getCalonPB();
    $data_get = 'id, nama, nik, alamat, tgl_periksa, status_pemeriksaan';
    $data['formpc'] = $this->M_utility->get_data($data_get, 'formpc', [])->result();
    $data['formpc_tahap_validasi'] = $this->M_utility->get_data($data_get, 'formpc', ['status_pemeriksaan' => 'Tahap validasi'])->result();
    $data['formpc_valid'] = $this->M_utility->get_data_where_in($data_get, 'formpc', 'status_pemeriksaan NOT', ['Belum diajukan', 'Tahap Validasi', 'Ditangguhkan'])->result();
    $data['formpc_ditangguhkan'] = $this->M_utility->get_data($data_get, 'formpc', ['status_pemeriksaan' => 'Ditangguhkan'])->result();

    $this->load->view('templates/header', $data);
    $this->load->view('templates/abp_sidebar', $data);
    $this->load->view('templates/topbar', $data);
    $this->load->view('ABP/daftarpc', $data);
    $this->load->view('templates/footer');
  }

  public function editpc($id)
  {
    $data['title'] = 'Halaman Edit Pemeriksaan Cepat';
    $data['sidebar']  = 'form-pemeriksaan';
    $data['formpc'] = $this->M_ABP->getFormpcById($id);
    $data['sex'] = ['Laki-laki', 'Perempuan'];
    $data['struktur'] = ['Rumah Dinding Tembok Terkekang','Rumah Dinding Tembok','Rumah Dinding Kayu','Rumah Dinding Tembok Kolom Kayu'];
    $data['lokasi'] = ['Risiko Rendah', 'Risiko Longsor','Risiko Tsunami', 'Ground Failure'];
    $data['kondisi'] = ['Tegak', 'Miring (> 2° teramati dengan mudah)'];
    $data['fondasi'] = ['Kurang dari 30%', '30-50%', 'Lebih dari 50%'];
    $data['dinding'] = ['Kurang dari 30%', '30-50%', 'Lebih dari 50%'];
    $data['rangka'] = ['Kurang dari 30%', '30-50%', 'Lebih dari 50%'];
    $data['atap'] = ['Kurang dari 30%', '30-50%', 'Lebih dari 50%'];
    $data['bantuan'] = ['Stimulan 1', 'Stimulan 2'];
    $data['rusak'] = ['Rusak Ringan', 'Rusak Sedang', 'Rusak Berat'];
    $data['status'] = ['Pribadi', 'Kontrak', 'Kos'];
    $data['subtitle'] = 'Edit Data Calon Penerima';
    $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

    // (Name , Alias atau nama lain)

    $this->form_validation->set_rules('nokk', 'NOKK', 'required|trim|numeric|integer|min_length[16]', [
      'required'   => 'No KK tidak boleh kosong!',
      'integer'    => 'No KK hanya berupa bilangan bulat!',
      'min_length' => 'No KK harus berjumlah 16 angka!',
      'numeric'    => 'No KK harus berupa angka!'
    ]);
    $this->form_validation->set_rules('nama', 'Nama', 'required|trim',[
      'required'   => 'Nama tidak boleh kosong!',
    ]);
    $this->form_validation->set_rules('sex', 'Sex', 'required',[
      'required'   => 'Jenis Kelamin harus dipilih!'
    ]);
    $this->form_validation->set_rules('pekerjaan', 'Pekerjaan', 'required',[
      'required'   => 'Pekerjaan tidak boleh kosong!',
    ]);
    $this->form_validation->set_rules('alamat', 'Alamat', 'required',[
      'required'   => 'Alamat tidak boleh kosong!',
    ]);
    $this->form_validation->set_rules('kelurahan', 'Kelurahan', 'required',[
      'required'   => 'Kelurahan tidak boleh kosong!',
    ]);
    $this->form_validation->set_rules('kecamatan', 'Kecamatan', 'required',[
      'required'   => 'Kecamatan tidak boleh kosong!',
    ]);


    if( $this->form_validation->run() == false){
      $this->load->view('templates/header', $data);
      $this->load->view('templates/abp_sidebar', $data);
      $this->load->view('templates/topbar', $data);
      $this->load->view('ABP/editpc', $data);
      $this->load->view('templates/footer');
    }
    else {
     $status_pemeriksaan = $this->M_utility->get_data('status_pemeriksaan', 'formpc', ['id' => $id], 1)->row()->status_pemeriksaan;
     if($status_pemeriksaan == 'Belum diajukan'){
         $data = [
            'nik' => htmlspecialchars ($this->input->post('nik', true)),
            'nokk' => htmlspecialchars($this->input->post('nokk', true)),
            'nama' => htmlspecialchars ($this->input->post('nama', true)),
            'tgl_lahir' => ($this->input->post('tgl_lahir', true)),
            'sex' => $this->input->post('sex', true),
            'no_hp' => htmlspecialchars ($this->input->post('no_hp', true)),
            'pekerjaan' => htmlspecialchars($this->input->post('pekerjaan', true)),
            'alamat' => $this->input->post('alamat', true),
            'kelurahan' => $this->input->post('kelurahan', true),
            'kecamatan' => $this->input->post('kecamatan', true),
            'struktur' => $this->input->post('struktur', true),
            'lokasi' => $this->input->post('lokasi', true),
            'latitude' => ($this->input->post('latitude', true)),
            'longitude' => ($this->input->post('longitude', true)),
            'kondisi' => $this->input->post('kondisi', true),
            'fondasi' => $this->input->post('fondasi', true),
            'dinding' => $this->input->post('dinding', true),
            'rangka' => $this->input->post('rangka', true),
            'atap' => $this->input->post('atap', true),
            'bantuan' => $this->input->post('bantuan', true),
            'rusak' => $this->input->post('rusak', true),
            'status' => $this->input->post('status', true),
            'nip' => htmlspecialchars ($this->input->post('nip', true)),
            'name' => htmlspecialchars($this->input->post('name', true)),
            'tgl_periksa' => ($this->input->post('tgl_periksa', true)),
            'catatan' => $this->input->post('catatan', true),
            'waktu_periksa' => ($this->input->post('waktu_periksa', true)),
          ];    
         
         $config['upload_path'] = './assets/img/rumah';
     		$config['allowed_types'] = 'jpg|png|jpeg';
     		$config['max_size']     = '2048';
     		$config['max_width'] = '3000';
     		$config['max_height'] = '5000';
         $this->load->library('upload', $config);
         
         if(!empty($_FILES['foto']['name'])){
            $nama_file = "foto_depan".uniqid();
        		$config['file_name']=$nama_file;
        		$this->upload->initialize($config);
        		$this->upload->do_upload("foto");
		      $gambar = $this->upload->data();
		      $data['foto']  = $gambar['file_name'];
         }
     		
     		if(!empty($_FILES['foto2']['name'])){
            $nama_file = "foto_samping".uniqid();
            $config['file_name']=$nama_file;
            $this->upload->initialize($config);
            $this->upload->do_upload("foto2");
            $gambar2 = $this->upload->data();
            $data['foto2'] = $gambar2['file_name'];
         }
         
         if(!empty($_FILES['foto3']['name'])){
            $nama_file = "foto_belakang".uniqid();
            $config['file_name']=$nama_file;
            $this->upload->initialize($config);
            $this->upload->do_upload("foto3");
            $gambar3 = $this->upload->data();
            $data['foto3'] =  $gambar3['file_name'];
         }

         if(!empty($_FILES['foto_kunjungan']['name'])){
            $nama_file = "foto_kunjungan".uniqid();
            $config['file_name']=$nama_file;
            $this->upload->initialize($config);
            $this->upload->do_upload("foto_kunjungan");
            $gambar4 = $this->upload->data();
            $data['foto_kunjungan'] = $gambar4['file_name'];
         }

         $this->M_ABP->edit($data);
         $this->session->set_flashdata('flash', 'Diubah');
         redirect('ABP/daftarpc');
     }else{
        $this->session->set_flashdata('flash', 'Laporan tidak dapat diubah');
        redirect('ABP/daftarpc');
     }

    }
  }

  public function detailpc($id)
  {
    $data['title']  = 'Halaman Detail Calon Penerima Bantuan';
    $data['sidebar']  = 'data-pemeriksaan-cepat';
    $data['subtitle'] = 'Detail Data Calon Penerima';
    $data['sex'] = ['Laki-laki', 'Perempuan'];
    $data['struktur'] = ['Rumah Dinding Tembok Terkekang','Rumah Dinding Tembok','Rumah Dinding Kayu','Rumah Dinding Tembok Kolom Kayu'];
    $data['lokasi'] = ['Risiko Rendah', 'Risiko Longsor','Risiko Tsunami', 'Ground Failure'];
    $data['kondisi'] = ['Tegak', 'Miring (> 2° teramati dengan mudah)'];
    $data['fondasi'] = ['Kurang dari 30%', '30-50%', 'Lebih dari 50%'];
    $data['dinding'] = ['Kurang dari 30%', '30-50%', 'Lebih dari 50%'];
    $data['rangka'] = ['Kurang dari 30%', '30-50%', 'Lebih dari 50%'];
    $data['atap'] = ['Kurang dari 30%', '30-50%', 'Lebih dari 50%'];
    $data['bantuan'] = ['Stimulan 1', 'Stimulan 2'];
    $data['rusak'] = ['Rusak Ringan', 'Rusak Sedang', 'Rusak Berat'];
    $data['status'] = ['Pribadi', 'Kontrak', 'Kos'];
    $data['user']   = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
    $data['formpc'] = $this->M_ABP->detail($id);
    $this->load->view('templates/header', $data);
    $this->load->view('templates/abp_sidebar', $data);
    $this->load->view('templates/topbar', $data);
    $this->load->view('PC/detailpc', $data);
    $this->load->view('templates/footer');
  }

  public function deletepc($id)
  {
     $status_pemeriksaan = $this->M_utility->get_data('status_pemeriksaan', 'formpc', ['id' => $id], 1)->row()->status_pemeriksaan;
     if($status_pemeriksaan == 'Belum diajukan'){
        $this->M_ABP->delete($id);
        $this->session->set_flashdata('flash', 'Dihapus');
        redirect('ABP/daftarpc');
     }else{
        $this->session->set_flashdata('flash', 'Laporan tidak dapat dihapus');
        redirect('ABP/daftarpc');
     }

  }

  public function ajukanpc($id)
  {
     $status_pemeriksaan = $this->M_utility->get_data('status_pemeriksaan', 'formpc', ['id' => $id], 1)->row()->status_pemeriksaan;
     if($status_pemeriksaan == 'Belum diajukan'){
        $this->M_ABP->update_status($id);
        $this->session->set_flashdata('flash', 'Diajukan');
        redirect('ABP/daftarpc');
     }else{
        $this->session->set_flashdata('flash', 'Laporan sudah diajukan');
        redirect('ABP/daftarpc');
     }
  }

  public function formrab()
  {
      $id_formpc = $this->input->get('id');

      $data['title'] = 'Halaman Form RAB';
      $data['subtitle'] = 'RAB Calon Penerima';
      $data['user'] = $this->db->get_where('user', ['email' =>
      $this->session->userdata('email')])->row_array();
      $data['penerima'] = $this->M_ABP->get_profile_rab($id_formpc)->row();
      $data['sidebar']  = 'form-pemeriksaan';
      $this->load->view('templates/header', $data);
      $this->load->view('templates/abp_sidebar', $data);
      $this->load->view('templates/topbar', $data);
      $this->load->view('ABP/formrab', $data);
      $this->load->view('templates/footer');

  }

}

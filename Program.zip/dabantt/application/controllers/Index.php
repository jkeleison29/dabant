<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Index extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
			$this->load->library('form_validation');
	}
   
	public function index()
	{
		$data ['title'] = "Dabant";
		$this->load->view('templates/Auth_header', $data);
		$this->load->view('Auth/index');
		$this->load->view('templates/Auth_footer');
	}

}

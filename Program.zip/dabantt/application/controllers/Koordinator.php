<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Koordinator extends CI_Controller
{
  public function __construct()
  {
    parent::__construct();
    is_logged_in();
    $this->load->model('M_ABP');
    $this->load->model('M_user');
    $this->load->model('M_utility');
    
    if($this->session->userdata('role_id') != 4){
       redirect('Auth');
    }
  }

  public function index()
  {
       $data_get = 'id, nama, nik, alamat, tgl_periksa, status_pemeriksaan';
       $formpc_menunggu_valid = $this->M_utility->get_data($data_get, 'formpc', ['status_pemeriksaan' => 'Menunggu verifikasi']);
       $data['formpc_list'] = $formpc_menunggu_valid->result();
       $data['formpc'] = $formpc_menunggu_valid->num_rows();
       $data['formpc_valid'] = $this->M_utility->get_data($data_get, 'formpc', ['status_pemeriksaan' => 'Proses persetujuan ABPP'])->num_rows();
       $data['formpc_ditangguhkan'] = $this->M_utility->get_data($data_get, 'formpc', ['status_pemeriksaan' => 'Ditangguhkan'])->num_rows();
       
       $data['title'] = 'Home Koordinator';
       $data['sidebar']  = 'dashboard';
       $data['user'] = $this->db->get_where('user', ['email' =>
       $this->session->userdata('email')])->row_array();
       $this->load->view('templates/header', $data);
       $this->load->view('templates/koordinator_sidebar', $data);
       $this->load->view('templates/topbar', $data);
       $this->load->view('Koordinator/index', $data);
       $this->load->view('templates/footer');
   }
   
   public function daftarpc()
     {
       $data['title']  = 'Halaman Daftar Calon Penerima Bantuan';
       $data['sidebar']  = 'data-pemeriksaan-cepat';
       $data['user']   = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
       
       $data['formpc_all'] = $this->M_ABP->get_formpc([])->result();
       $data['formpc'] = $this->M_ABP->get_formpc(['status_pemeriksaan' => 'Menunggu verifikasi'])->result();
       $data['formpc_valid'] = $this->M_ABP->get_formpc(['status_pemeriksaan' => 'Proses persetujuan ABPP'])->result();
       $data['formpc_ditangguhkan'] = $this->M_ABP->get_formpc(['status_pemeriksaan' => 'Ditangguhkan'])->result();
       
	   $this->load->view('templates/header', $data);
       $this->load->view('templates/koordinator_sidebar', $data);
       $this->load->view('templates/topbar', $data);
       $this->load->view('Koordinator/daftarpc', $data);
       $this->load->view('templates/footer');
     }
     
     
    public function detailpc($id)
     {
       $data['sidebar']  = 'data-pemeriksaan-cepat';
       $data['title']  = 'Halaman Detail Calon Penerima Bantuan';
       $data['subtitle'] = 'Detail Data Calon Penerima';
       $data['sex'] = ['Laki-laki', 'Perempuan'];
       $data['struktur'] = ['Rumah Dinding Tembok Terkekang','Rumah Dinding Tembok','Rumah Dinding Kayu','Rumah Dinding Tembok Kolom Kayu'];
       $data['lokasi'] = ['Risiko Rendah', 'Risiko Longsor','Risiko Tsunami', 'Ground Failure'];
       $data['kondisi'] = ['Tegak', 'Miring (> 2° teramati dengan mudah)'];
       $data['fondasi'] = ['Kurang dari 30%', '30-50%', 'Lebih dari 50%'];
       $data['dinding'] = ['Kurang dari 30%', '30-50%', 'Lebih dari 50%'];
       $data['rangka'] = ['Kurang dari 30%', '30-50%', 'Lebih dari 50%'];
       $data['atap'] = ['Kurang dari 30%', '30-50%', 'Lebih dari 50%'];
       $data['bantuan'] = ['Stimulan 1', 'Stimulan 2'];
       $data['rusak'] = ['Rusak Ringan', 'Rusak Sedang', 'Rusak Berat'];
       $data['status'] = ['Pribadi', 'Kontrak', 'Kos'];
       $data['user']   = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
       $data['formpc'] = $this->M_ABP->detail($id);
       
       $this->load->view('templates/header', $data);
       $this->load->view('templates/koordinator_sidebar', $data);
       $this->load->view('templates/topbar', $data);
       $this->load->view('PC/detailpc', $data);
       $this->load->view('templates/footer');
     }
   
     
    //====== FUNGSI PEMROSESAN DATA  ======/

    public function verifikasi(){
      $formpc_id = $this->input->post('formpc-id');
      $verifikasi = $this->input->post('verifikasi');
      $keterangan = $this->input->post('keterangan');
      
      if($verifikasi == 'disetujui'){
         $status =  "Proses persetujuan ABPP";
      }else{
         $status =  "Ditangguhkan";
      }
      
      //Insert tabel verifikasi
      $data = [
         'id_formpc' => $formpc_id,
         'id_user' => $this->session->userdata('id_user'),
         'status' => $status,
         'keterangan' => $keterangan,
         'tanggal_periksa' => date('Y-m-d H:i:s')
      ];
      $this->M_utility->insert_data($data, 'verifikasi');
      
      //Update status formpc
      $data = [
		'status_pemeriksaan' => $status,
		'keterangan_pemeriksaan' => $keterangan
	  ];
      $this->M_utility->edit('formpc', ['id' => $formpc_id], $data);
      redirect('Koordinator/daftarpc');
    }
    
 
}

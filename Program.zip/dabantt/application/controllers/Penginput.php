<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Penginput extends CI_Controller
{
  public function __construct()
  {
    parent::__construct();
    is_logged_in();
    $this->load->model('M_ABP');
    $this->load->model('M_user');
    $this->load->model('M_utility');

     if($this->session->userdata('role_id') != 1){
        redirect('Auth');
     }
  }

  public function index()
  {
       $data_get = 'id, nama, nik, alamat, tgl_periksa, status_pemeriksaan';
       $formpc_menunggu_valid = $this->M_utility->get_data($data_get, 'formpc', ['status_pemeriksaan' => 'Tahap Validasi']);
       $data['formpc_list'] = $formpc_menunggu_valid->result();
       $data['formpc'] = $formpc_menunggu_valid->num_rows();
       $data['formpc_valid'] = $this->M_utility->get_data($data_get, 'formpc', ['status_pemeriksaan' => 'Menunggu verifikasi'])->num_rows();
       $data['formpc_ditangguhkan'] = $this->M_utility->get_data($data_get, 'formpc', ['status_pemeriksaan' => 'Ditangguhkan'])->num_rows();

       $data['title'] = 'Home Tim Penginput';
       $data['sidebar']  = 'dashboard';
       $data['user'] = $this->db->get_where('user', ['email' =>
       $this->session->userdata('email')])->row_array();
       $this->load->view('templates/header', $data);
       $this->load->view('templates/penginput_sidebar', $data);
       $this->load->view('templates/topbar', $data);
       $this->load->view('Penginput/index', $data);
       $this->load->view('templates/footer');
   }

   public function daftarpc()
     {
       $data['title']  = 'Halaman Daftar Calon Penerima Bantuan';
       $data['sidebar']  = 'data-pemeriksaan-cepat';
       $data['user']   = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
       $data['formpc'] = $this->M_ABP->get_formpc(['status_pemeriksaan' => 'Tahap Validasi'])->result();
       $data['formpc_valid'] = $this->M_ABP->get_formpc(['status_pemeriksaan' => 'Menunggu verifikasi'])->result();
       $data['formpc_ditangguhkan'] = $this->M_ABP->get_formpc(['status_pemeriksaan' => 'Ditangguhkan'])->result();
       $this->load->view('templates/header', $data);
       $this->load->view('templates/penginput_sidebar', $data);
       $this->load->view('templates/topbar', $data);
       $this->load->view('Penginput/daftarpc', $data);
       $this->load->view('templates/footer');
     }


    public function detailpc($id)
     {
       $data['sidebar']  = 'data-pemeriksaan-cepat';
       $data['title']  = 'Halaman Detail Calon Penerima Bantuan';
       $data['subtitle'] = 'Detail Data Calon Penerima';
       $data['sex'] = ['Laki-laki', 'Perempuan'];
       $data['struktur'] = ['Rumah Dinding Tembok Terkekang','Rumah Dinding Tembok','Rumah Dinding Kayu','Rumah Dinding Tembok Kolom Kayu'];
       $data['lokasi'] = ['Risiko Rendah', 'Risiko Longsor','Risiko Tsunami', 'Ground Failure'];
       $data['kondisi'] = ['Tegak', 'Miring (> 2° teramati dengan mudah)'];
       $data['fondasi'] = ['Kurang dari 30%', '30-50%', 'Lebih dari 50%'];
       $data['dinding'] = ['Kurang dari 30%', '30-50%', 'Lebih dari 50%'];
       $data['rangka'] = ['Kurang dari 30%', '30-50%', 'Lebih dari 50%'];
       $data['atap'] = ['Kurang dari 30%', '30-50%', 'Lebih dari 50%'];
       $data['bantuan'] = ['Stimulan 1', 'Stimulan 2'];
       $data['rusak'] = ['Rusak Ringan', 'Rusak Sedang', 'Rusak Berat'];
       $data['status'] = ['Pribadi', 'Kontrak', 'Kos'];
       $data['user']   = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
       $data['formpc'] = $this->M_ABP->detail($id);

       $this->load->view('templates/header', $data);
       $this->load->view('templates/penginput_sidebar', $data);
       $this->load->view('templates/topbar', $data);
       $this->load->view('PC/detailpc', $data);
       $this->load->view('templates/footer');
     }

     public function timpendamping()
     {
       $this->form_validation->set_rules('nip', 'NIP', 'required|trim|numeric|integer|min_length[18]|is_unique[user.nip]', [
         'required'   => 'NIP tidak boleh kosong!',
         'numeric'    => 'NIP harus berupa angka!',
         'integer'    => 'NIP hanya berupa bilangan bulat!',
         'min_length' => 'NIP harus berjumlah 16 angka!',
         'is_unique'  => 'NIP sudah terdaftar!'
       ]);
       $data['title']  = 'Halaman Daftar Tim Pendamping';
       $data['sidebar']  = 'tim-pendamping';
       $data['user']   = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

//       $data['formpc'] = $this->M_ABP->pagination($config['per_page'], $data['start'], $data['keyword']);
       $this->load->view('templates/header', $data);
       $this->load->view('templates/penginput_sidebar', $data);
       $this->load->view('templates/topbar', $data);
       $this->load->view('Penginput/daftarpendamping');
       $this->load->view('templates/footer');
     }

    //====== FUNGSI PEMROSESAN DATA  ======/
    public function get_data_pendamping(){
       $data = $this->M_user->get_user_active()->result();
       echo json_encode($data);
    }

    public function get_pendamping_edit(){
      $id = $this->input->get('id');
      $data = $this->M_user->get_user_active(['user.id' => $id])->result();
      echo json_encode($data);
    }

    public function verifikasi_calon(){
      $formpc_id = $this->input->post('formpc-id');

      
      $cek_status = $this->M_utility->get_data('status_pemeriksaan', 'formpc', ['id' => $formpc_id], 1)->row()->status_pemeriksaan;
      
      if($cek_status == 'Menunggu verifikasi'){
         $status = 'Tahap Validasi';
      }else{
         $status = 'Menunggu verifikasi';
      }
      

      //Insert tabel verifikasi_penginput
      $data = [
         'id_formpc' => $formpc_id,
         'id_user' => $this->session->userdata('id_user'),
         'status' => $status,
         'tanggal_periksa' => date('Y-m-d H:i:s')
      ];
      $this->M_utility->insert_data($data, 'verifikasi');

      //Update status formpc
      $data = ['status_pemeriksaan' => $status];
      $this->M_utility->edit('formpc', ['id' => $formpc_id], $data);
      redirect('Penginput/daftarpc');
    }


    public function editpc($id)
    {
       $data['title'] = 'Halaman Edit Pemeriksaan Cepat';
       $data['sidebar']  = 'form-pemeriksaan';
       $data['formpc'] = $this->M_ABP->getFormpcById($id);
       $data['sex'] = ['Laki-laki', 'Perempuan'];
       $data['struktur'] = ['Rumah Dinding Tembok Terkekang','Rumah Dinding Tembok','Rumah Dinding Kayu','Rumah Dinding Tembok Kolom Kayu'];
       $data['lokasi'] = ['Risiko Rendah', 'Risiko Longsor','Risiko Tsunami', 'Ground Failure'];
       $data['kondisi'] = ['Tegak', 'Miring (> 2° teramati dengan mudah)'];
       $data['fondasi'] = ['Kurang dari 30%', '30-50%', 'Lebih dari 50%'];
       $data['dinding'] = ['Kurang dari 30%', '30-50%', 'Lebih dari 50%'];
       $data['rangka'] = ['Kurang dari 30%', '30-50%', 'Lebih dari 50%'];
       $data['atap'] = ['Kurang dari 30%', '30-50%', 'Lebih dari 50%'];
       $data['bantuan'] = ['Stimulan 1', 'Stimulan 2'];
       $data['rusak'] = ['Rusak Ringan', 'Rusak Sedang', 'Rusak Berat'];
       $data['status'] = ['Pribadi', 'Kontrak', 'Kos'];
       $data['subtitle'] = 'Edit Data Calon Penerima';
       $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

      $this->load->view('templates/header', $data);
      $this->load->view('templates/penginput_sidebar', $data);
      $this->load->view('templates/topbar', $data);
      $this->load->view('Penginput/editpc', $data);
      $this->load->view('templates/footer');
     }

     public function submit_editpc(){
       $this->form_validation->set_rules('nokk', 'NOKK', 'required|trim|numeric|integer|min_length[16]', [
         'required'   => 'No KK tidak boleh kosong!',
         'integer'    => 'No KK hanya berupa bilangan bulat!',
         'min_length' => 'No KK harus berjumlah 16 angka!',
         'numeric'    => 'No KK harus berupa angka!'
       ]);
       $this->form_validation->set_rules('nama', 'Nama', 'required|trim',[
         'required'   => 'Nama tidak boleh kosong!',
       ]);
       $this->form_validation->set_rules('sex', 'Sex', 'required',[
         'required'   => 'Jenis Kelamin harus dipilih!'
       ]);
       $this->form_validation->set_rules('pekerjaan', 'Pekerjaan', 'required',[
         'required'   => 'Pekerjaan tidak boleh kosong!',
       ]);
       $this->form_validation->set_rules('alamat', 'Alamat', 'required',[
         'required'   => 'Alamat tidak boleh kosong!',
       ]);
       $this->form_validation->set_rules('kelurahan', 'Kelurahan', 'required',[
         'required'   => 'Kelurahan tidak boleh kosong!',
       ]);
       $this->form_validation->set_rules('kecamatan', 'Kecamatan', 'required',[
         'required'   => 'Kecamatan tidak boleh kosong!',
       ]);


       if( $this->form_validation->run() == false){
         $this->session->set_flashdata('flash', 'Data tidak valid');
         redirect('Penginput/daftarpc');
       }
       else {
         $data = [
            'nik' => htmlspecialchars ($this->input->post('nik', true)),
            'nokk' => htmlspecialchars($this->input->post('nokk', true)),
            'nama' => htmlspecialchars ($this->input->post('nama', true)),
            'tgl_lahir' => ($this->input->post('tgl_lahir', true)),
            'sex' => $this->input->post('sex', true),
            'no_hp' => htmlspecialchars ($this->input->post('no_hp', true)),
            'pekerjaan' => htmlspecialchars($this->input->post('pekerjaan', true)),
            'alamat' => $this->input->post('alamat', true),
            'kelurahan' => $this->input->post('kelurahan', true),
            'kecamatan' => $this->input->post('kecamatan', true),
            'struktur' => $this->input->post('struktur', true),
            'lokasi' => $this->input->post('lokasi', true),
            'latitude' => ($this->input->post('latitude', true)),
            'longitude' => ($this->input->post('longitude', true)),
            'kondisi' => $this->input->post('kondisi', true),
            'fondasi' => $this->input->post('fondasi', true),
            'dinding' => $this->input->post('dinding', true),
            'rangka' => $this->input->post('rangka', true),
            'atap' => $this->input->post('atap', true),
            'bantuan' => $this->input->post('bantuan', true),
            'rusak' => $this->input->post('rusak', true),
            'status' => $this->input->post('status', true),
            'nip' => htmlspecialchars ($this->input->post('nip', true)),
            'name' => htmlspecialchars($this->input->post('name', true)),
            'tgl_periksa' => ($this->input->post('tgl_periksa', true)),
            'catatan' => $this->input->post('catatan', true),
            'waktu_periksa' => ($this->input->post('waktu_periksa', true)),
          ];    
         
         $config['upload_path'] = './assets/img/rumah';
     		$config['allowed_types'] = 'jpg|png|jpeg';
     		$config['max_size']     = '2048';
     		$config['max_width'] = '3000';
     		$config['max_height'] = '5000';
         $this->load->library('upload', $config);
         
         if(!empty($_FILES['foto']['name'])){
            $nama_file = "foto_depan".uniqid();
        		$config['file_name']=$nama_file;
        		$this->upload->initialize($config);
        		$this->upload->do_upload("foto");
		      $gambar = $this->upload->data();
		      $data['foto']  = $gambar['file_name'];
         }
     		
     		if(!empty($_FILES['foto2']['name'])){
            $nama_file = "foto_samping".uniqid();
            $config['file_name']=$nama_file;
            $this->upload->initialize($config);
            $this->upload->do_upload("foto2");
            $gambar2 = $this->upload->data();
            $data['foto2'] = $gambar2['file_name'];
         }
         
         if(!empty($_FILES['foto3']['name'])){
            $nama_file = "foto_belakang".uniqid();
            $config['file_name']=$nama_file;
            $this->upload->initialize($config);
            $this->upload->do_upload("foto3");
            $gambar3 = $this->upload->data();
            $data['foto3'] =  $gambar3['file_name'];
         }

         if(!empty($_FILES['foto_kunjungan']['name'])){
            $nama_file = "foto_kunjungan".uniqid();
            $config['file_name']=$nama_file;
            $this->upload->initialize($config);
            $this->upload->do_upload("foto_kunjungan");
            $gambar4 = $this->upload->data();
            $data['foto_kunjungan'] = $gambar4['file_name'];
         }
       
       
         $this->M_ABP->edit($data);
         $this->session->set_flashdata('flash', 'Diubah');
         redirect('Penginput/daftarpc');
       }
     }

     public function deletepc($id)
     {
        if($this->session->userdata('role_id') != 1){
           redirect();
        }
        $this->M_ABP->delete($id);
        $this->session->set_flashdata('flash', 'Dihapus');
        redirect('Penginput/daftarpc');
     }

    public function tambah_pendamping(){
      $nip = $this->input->post('nip');
      $nama = $this->input->post('nama');
      $email = $this->input->post('email');
      $role = $this->input->post('role');
      $password = substr(uniqid(), 0, 7); // Mengambil 7 karakter random untuk dijadikan password

      //Insert tabel verifikasi_penginput
      $data = [
         'nip' => $nip,
         'name' => $nama,
         'email' => $email,
         'password' => password_hash($password, PASSWORD_DEFAULT),
         'role_id' => $role,
         'is_active' => 1,
         'date_created' => date('Y-m-d H:i:s')
      ];
      $this->M_utility->insert_data($data, 'user');

      echo json_encode($password);
    }

    public function edit_pendamping(){
      $id = $this->input->post('id-pendamping');
      $nip = $this->input->post('nip');
      $nama = $this->input->post('nama');
      $email = $this->input->post('email');
      $role = $this->input->post('role');

      //Insert tabel verifikasi_penginput
      $data = [
         'nip' => $nip,
         'name' => $nama,
         'email' => $email,
         'role_id' => $role,
      ];
      $this->M_utility->edit('user', ['user.id' => $id], $data);

      echo json_encode(200);
    }

    public function hapus_pendamping(){
      $id = $this->uri->segment(3);
      $this->M_utility->delete_data('user', ['id' => $id]);
      echo json_encode(200);
    }
}

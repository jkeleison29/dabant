<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ABPP extends CI_Controller
{
  public function __construct()
  {
    parent::__construct();
    is_logged_in();
    $this->load->model('M_user');
    $this->load->model('M_utility');
    
     if($this->session->userdata('role_id') != 3){
        redirect('Auth');
     }
  }

  public function index()
  {
    $data_get = 'id, nama, nik, alamat, tgl_periksa, status_pemeriksaan';
    $formpc_menunggu_valid = $this->M_utility->get_data($data_get, 'formpc', ['status_pemeriksaan' => 'Proses persetujuan ABPP']);
    $data['formpc_list'] = $formpc_menunggu_valid->result();
    $data['formpc_menunggu'] = $formpc_menunggu_valid->num_rows();
    $data['formpc_valid'] = $this->M_utility->get_data($data_get, 'formpc', ['status_pemeriksaan' => 'Sudah menerima bantuan'])->num_rows();
    $data['formpc_ditangguhkan'] = $this->M_utility->get_data($data_get, 'formpc', ['status_pemeriksaan' => 'Ditangguhkan'])->num_rows();
    $data['title'] = 'Home Asisten Bidang Pembiayaan dan Pencairan';
    $data['sidebar']  = 'dashboard';
    $data['user'] = $this->db->get_where('user', ['email' =>
    $this->session->userdata('email')])->row_array();
    $this->load->view('templates/header', $data);
    $this->load->view('templates/abpp_sidebar', $data);
    $this->load->view('templates/topbar', $data);
    $this->load->view('ABPP/index', $data);
    $this->load->view('templates/footer');
  }
  
  public function daftarpc()
     {
       $data['title']  = 'Halaman Daftar Calon Penerima Bantuan';
       $data['sidebar']  = 'data-pemeriksaan-cepat';
       $data['user']   = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
       
       $data_get = 'id, nama, nik, alamat, tgl_periksa, status_pemeriksaan';
       $data['formpc'] = $this->M_utility->get_data($data_get, 'formpc', ['status_pemeriksaan' => 'Proses persetujuan ABPP'])->result();
       $data['formpc_valid'] = $this->M_utility->get_data($data_get, 'formpc', ['status_pemeriksaan' => 'Sudah menerima bantuan'])->result();
       $this->load->view('templates/header', $data);
       $this->load->view('templates/abpp_sidebar', $data);
       $this->load->view('templates/topbar', $data);
       $this->load->view('ABPP/daftarpc', $data);
       $this->load->view('templates/footer');
     }
  
   public function detailpc($id)
     {
       $data['sidebar']  = 'data-pemeriksaan-cepat';
       $data['title']  = 'Halaman Detail Calon Penerima Bantuan';
       $data['subtitle'] = 'Detail Data Calon Penerima';
       $data['sex'] = ['Laki-laki', 'Perempuan'];
       $data['struktur'] = ['Rumah Dinding Tembok Terkekang','Rumah Dinding Tembok','Rumah Dinding Kayu','Rumah Dinding Tembok Kolom Kayu'];
       $data['lokasi'] = ['Risiko Rendah', 'Risiko Longsor','Risiko Tsunami', 'Ground Failure'];
       $data['kondisi'] = ['Tegak', 'Miring (> 2° teramati dengan mudah)'];
       $data['fondasi'] = ['Kurang dari 30%', '30-50%', 'Lebih dari 50%'];
       $data['dinding'] = ['Kurang dari 30%', '30-50%', 'Lebih dari 50%'];
       $data['rangka'] = ['Kurang dari 30%', '30-50%', 'Lebih dari 50%'];
       $data['atap'] = ['Kurang dari 30%', '30-50%', 'Lebih dari 50%'];
       $data['bantuan'] = ['Stimulan 1', 'Stimulan 2'];
       $data['rusak'] = ['Rusak Ringan', 'Rusak Sedang', 'Rusak Berat'];
       $data['status'] = ['Pribadi', 'Kontrak', 'Kos'];
       $data['user']   = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
       $data['formpc'] = $this->M_ABP->detail($id);
       
       $this->load->view('templates/header', $data);
       $this->load->view('templates/abpp_sidebar', $data);
       $this->load->view('templates/topbar', $data);
       $this->load->view('PC/detailpc', $data);
       $this->load->view('templates/footer');
     }
     
     
   //====== FUNGSI PEMROSESAN DATA  ======/
     
   public function persetujuan(){
      $formpc_id = $this->input->post('formpc-id');
      
      $cek_status = $this->M_utility->get_data('status_pemeriksaan', 'formpc', ['id' => $formpc_id], 1)->row()->status_pemeriksaan;
      
      if($cek_status == 'Sudah menerima bantuan'){
         $status = 'Proses persetujuan ABPP';
      }else{
         $status = 'Sudah menerima bantuan';
      }
      
      //Insert tabel verifikasi
      $data = [
         'id_formpc' => $formpc_id,
         'id_user' => $this->session->userdata('id_user'),
         'status' => $status,
         'keterangan' => '',
         'tanggal_periksa' => date('Y-m-d H:i:s')
      ];
      $this->M_utility->insert_data($data, 'verifikasi');
      
      //Update status formpc
      $data = ['status_pemeriksaan' => $status];
      $this->M_utility->edit('formpc', ['id' => $formpc_id], $data);
      redirect('ABPP/daftarpc');
    }
}

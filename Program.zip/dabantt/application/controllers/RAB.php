<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class RAB extends CI_Controller
{
  public function __construct()
  {
    parent::__construct();
    is_logged_in();
    $this->load->model('M_utility');
  }

  public function rab(){
      $id_formpc = $this->uri->segment(3);
      $data['title'] = 'Halaman Form RAB';
      $data['subtitle'] = 'RAB Calon Penerima';
      $data['user'] = $this->db->get_where('user', ['email' =>
      $this->session->userdata('email')])->row_array();
      $data['penerima'] = $this->M_ABP->get_profile_rab($id_formpc)->row();
      $data['sidebar']  = 'form-pemeriksaan';
      $this->load->view('templates/header', $data);
      
      if($this->session->userdata('role_id') == 1){
         $this->load->view('templates/penginput_sidebar', $data);      
      }else if($this->session->userdata('role_id') == 3){
         $this->load->view('templates/abpp_sidebar', $data);      
      }else if($this->session->userdata('role_id') == 4){
         $this->load->view('templates/koordinator_sidebar', $data);      
      }

      $this->load->view('templates/topbar', $data);
      $this->load->view('RAB/formrab', $data);
      $this->load->view('templates/footer');
  }

  public function get_rab_json()
  {
      $id_formpc = $this->input->get('formpc');
      $data = $this->M_utility->get_data('*', 'rab', ['id_formpc' => $id_formpc])->result();
      echo json_encode($data);
  }
  
  public function get_rab_edit(){
      $id_rab = $this->input->get('id');
      $data = $this->M_utility->get_data('*', 'rab', ['id_rab' => $id_rab], 1)->result();
      echo json_encode($data);
  }
  
  public function create_rab(){
      $id_formpc = $this->input->post('formpc');
      $nama_barang = $this->input->post('nama-barang');
      $satuan = $this->input->post('satuan');
      $volume = $this->input->post('volume');
      $harga = $this->input->post('harga');
      $jumlah = $this->input->post('jumlah');
      
      $status_pemeriksaan = $this->M_utility->get_data('status_pemeriksaan', 'formpc', ['id' => $id_formpc], 1)->row()->status_pemeriksaan;
        if($status_pemeriksaan != 'Belum diajukan'){
            return false;
        }
           
      $data = array(
         'id_formpc' => $id_formpc,
         'nama_barang' => $nama_barang,
         'satuan' => $satuan,
         'volume' => preg_replace('/[^0-9]/', '', $volume),
         'harga_satuan' => preg_replace('/[^0-9]/', '', $harga),
         'jumlah_harga' => preg_replace('/[^0-9]/', '', $jumlah)
      );
      $this->M_utility->insert_data($data, 'rab');
      echo json_encode('200');
  }
  
    public function edit_rab(){
      $id_rab = $this->input->post('id-rab');
      $nama_barang = $this->input->post('nama-barang');
      $satuan = $this->input->post('satuan');
      $volume = $this->input->post('volume');
      $harga = $this->input->post('harga');
      $jumlah = $this->input->post('jumlah');
      
      $data = array(
         'nama_barang' => $nama_barang,
         'satuan' => $satuan,
         'volume' => preg_replace('/[^0-9]/', '', $volume),
         'harga_satuan' => preg_replace('/[^0-9]/', '', $harga),
         'jumlah_harga' => preg_replace('/[^0-9]/', '', $jumlah)
      );
      $this->M_utility->edit('rab', ['id_rab' => $id_rab], $data);
      echo json_encode('200');
  }
  
  public function delete_rab(){
     $id_rab = $this->input->get('rab');
     $this->M_utility->delete_data('rab', ['id_rab' => $id_rab]); 
     echo json_encode('200');
  }
}

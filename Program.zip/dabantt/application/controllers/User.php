<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller
{
  public function __construct()
  {
    parent::__construct();
//    is_logged_in();
    $this->load->model('M_user');
    $this->load->model('M_utility');
  }

  public function ktp()
  {
       $this->load->view('User/user_man.php'); 
  }
  
  public function add_ktp()
  {
      $csv = $_FILES['csv']['tmp_name'];

      $handle = fopen($csv,"r");
      while (($row = fgetcsv($handle, 10000, ",")) != FALSE) //get row vales
      {
          print_r($row); //rows in array

         //here you can manipulate the values by accessing the array
      }
  }

  public function index()
  {
    $data['title'] = 'Halaman Profile';
    $data['sidebar']  = 'profile';
    $data['user'] = $this->db->get_where('user', ['email' =>
    $this->session->userdata('email')])->row_array();
    $this->load->view('templates/header', $data);
    $this->load->view('templates/user_sidebar', $data);
    $this->load->view('templates/topbar', $data);
    $this->load->view('User/index', $data);
    $this->load->view('templates/footer');
  }
  
  public function daftarpc()
     {
       $data['title']  = 'Halaman Daftar Calon Penerima Bantuan';
       $data['sidebar']  = 'data-pemeriksaan-cepat';
       $data['user']   = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
       
       $data_get = 'id, nama, nik, alamat, tgl_periksa, status_pemeriksaan';
       $data['formpc'] = $this->M_utility->get_data($data_get, 'formpc', ['status_pemeriksaan' => 'Proses persetujuan ABPP'])->result();
       $data['formpc_valid'] = $this->M_utility->get_data($data_get, 'formpc', ['status_pemeriksaan' => 'Sudah menerima bantuan'])->result();
       $this->load->view('templates/header', $data);
       $this->load->view('templates/abpp_sidebar', $data);
       $this->load->view('templates/topbar', $data);
       $this->load->view('ABPP/daftarpc', $data);
       $this->load->view('templates/footer');
     }
  
   public function detailpc($id)
     {
       $data['sidebar']  = 'data-pemeriksaan-cepat';
       $data['title']  = 'Halaman Detail Calon Penerima Bantuan';
       $data['subtitle'] = 'Detail Data Calon Penerima';
       $data['sex'] = ['Laki-laki', 'Perempuan'];
       $data['struktur'] = ['Rumah Dinding Tembok Terkekang','Rumah Dinding Tembok','Rumah Dinding Kayu','Rumah Dinding Tembok Kolom Kayu'];
       $data['lokasi'] = ['Risiko Rendah', 'Risiko Longsor','Risiko Tsunami', 'Ground Failure'];
       $data['kondisi'] = ['Tegak', 'Miring (> 2° teramati dengan mudah)'];
       $data['fondasi'] = ['Kurang dari 30%', '30-50%', 'Lebih dari 50%'];
       $data['dinding'] = ['Kurang dari 30%', '30-50%', 'Lebih dari 50%'];
       $data['rangka'] = ['Kurang dari 30%', '30-50%', 'Lebih dari 50%'];
       $data['atap'] = ['Kurang dari 30%', '30-50%', 'Lebih dari 50%'];
       $data['bantuan'] = ['Stimulan 1', 'Stimulan 2'];
       $data['rusak'] = ['Rusak Ringan', 'Rusak Sedang', 'Rusak Berat'];
       $data['status'] = ['Pribadi', 'Kontrak', 'Kos'];
       $data['user']   = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
       $data['formpc'] = $this->M_ABP->detail($id);
       
       $this->load->view('templates/header', $data);
       $this->load->view('templates/abpp_sidebar', $data);
       $this->load->view('templates/topbar', $data);
       $this->load->view('ABPP/detailpc', $data);
       $this->load->view('templates/footer');
     }
     
     
   //====== FUNGSI PEMROSESAN DATA  ======/
   
   public function get_profile(){
      $id_user = $this->session->userdata('id_user');
      $data = $this->M_user->get_user_profile($id_user)->row();
      echo json_encode($data);
   }
     
   public function persetujuan(){
      $formpc_id = $this->input->post('formpc-id');
      $cek_status = $this->M_utility->get_data('status_pemeriksaan', 'formpc', ['status_pemeriksaan' => 'Sudah menerima bantuan'], 1)->row()->status_pemeriksaan;
      if($cek_status == 'Sudah menerima bantuan'){
         $status = 'Proses persetujuan ABPP';
      }else{
         $status = 'Sudah menerima bantuan';
      }
      
      //Insert tabel verifikasi
      $data = [
         'id_formpc' => $formpc_id,
         'id_user' => $this->session->userdata('id_user'),
         'status' => $status,
         'keterangan' => '',
         'tanggal_periksa' => date('Y-m-d H:i:s')
      ];
      $this->M_utility->insert_data($data, 'verifikasi');
      
      //Update status formpc
      $data = ['status_pemeriksaan' => $status];
      $this->M_utility->edit('formpc', ['id' => $formpc_id], $data);
      redirect('ABPP/daftarpc');
    }
    
    
    public function edit_profile(){
      $id_user = $this->input->post('id-user-profile');     
      $nama = $this->input->post('user-name');     
      $nip = $this->input->post('user-nip');     
      $old_password = $this->input->post('old-password');     
      $new_password = $this->input->post('new-password');     
      
      //Check if user want to change password
      if($old_password != ''){
         if($new_passwrord == ''){
            echo json_encode('PASSWORD_EMPTY');
         }else{
            $password = $this->M_utility->get_data('user.password', 'user', ['id' => $id_user])->row()->password;            
            if(password_verify($password, $old_password)){
               $this->M_utility->edit('user', ['id' => $id_user], ['password' => password_hash($new_password, PASSWORD_DEFAULT)]);
            }else{
               echo json_encode('PASSWORD_FALSE');
            }
         }
      }
      
      // Change user profile
      $data_profile = [
         'name' => $nama,
         'nip' => $nip
      ];
      
      $this->M_utility->edit('user', ['id' => $id_user], $data_profile);
      echo json_encode(200);
    }
   
   public function get_penerima_bantuan(){
      $where = ['status_pemeriksaan' => 'Sudah menerima bantuan'];
      if($this->input->post('search') != null){
         $where = ['nik' => $this->input->post('search')];
      }
      $data = $this->M_utility->get_data('*', 'formpc', $where)->result();
      echo json_encode($data);
   }
   
   public function get_sebaran_penerima(){
      $data = $this->M_user->get_sebaran_penerima()->result();
      echo json_encode($data);
   }
}

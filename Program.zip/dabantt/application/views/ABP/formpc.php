<!-- Begin Page Content -->
<div class="container-fluid">


  <!-- Page Heading -->
  <div class="section-title text-center">
  <h1 class="h4 mb-4 text-gray-800"><?= $subtitle; ?></h1>
  </div>

   <!-- Seluruh Isi -->
    <div class="row">
      <!--ID TAB=CP -->
      <div class="col-md-12" id="tab-cp"></div>
      <div class="col-md-12 mt-3">

    <div class="col-md">
      <?php if ($this->session->flashdata('flash')) : ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">Data Calon Penerima
          <strong>berhasil </strong><?= $this->session->flashdata('flash'); ?>
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
      <?php endif; ?>
    </div>

  <form class="user" enctype = "multipart/form-data" method="post"  action="<?= base_url('ABP/formpc'); ?>" role= "form">
   <div class="card wow fadeInUp ml-3" id="get-started" style="visibility: visible; animation-name: fadeInUp;">
       <div class="card-body">
          <ul class="nav nav-tabs" id="pills-tab" role="tablist">
            <li class="nav-item">
              <a class="nav-link disabled active" id="pills-satu-tab" data-toggle="pill" href="#pills-satu" role="tab" aria-controls="pills-satu" aria-selected="true">Data Calon Penerima</a>
            </li>
          </ul>
          <br>
          <div class="tab-content" id="pills-tabContent">
            <!-- Tab Data Calon Penerima -->
            <div class="tab-pane fade show active" id="pills-satu" role="tabpanel" aria-labelledby="pills-satu-tab">
              <div class="form-row col-md-12">

                <div class="form-group col-md-4">
                  <label for="NIK" class="control-label">NIK <span class="text-danger">*</span> </label>
                   <input type="text" class="form-control" id="nik" name="nik" min_length="16" maxlength="16" placeholder="Masukkan NIK" value="<?= set_value('nik'); ?>">
                  <?= form_error('nik', '<small class="text-danger pl-3">', '</small>' )?>
                </div>

                <div class="form-group col-md-4">
                  <label for="NOKK" class="control-label">Nomor KK (Kartu Keluarga) <span class="text-danger">*</span> </label>
                 <input type="text" class="form-control" id="nokk" name="nokk" min_length="16" maxlength="16" placeholder="Masukkan NOKK" value="<?= set_value('nokk'); ?>">
                <?= form_error('nokk', '<small class="text-danger pl-3">', '</small>' )?>
                </div>

                <div class="form-group col-md-4">
                  <label for="nama" class="control-label">Nama Lengkap <span class="text-danger">*</span> </label>
                 <input type="text" class="form-control" id="nama" name="nama" placeholder="Masukkan Nama Lengkap" value="<?= set_value('nama'); ?>">
                <?= form_error('nama', '<small class="text-danger pl-3">', '</small>' )?>
                </div>

                 <div class="form-group col-md-4">
                  <label for="tgl_lahir" class="control-label">Tanggal Lahir <span class="text-danger">*</span> </label>
                  <input type="date" id="tgl_lahir" name="tgl_lahir" class="form-control" placeholder="dd/mm/yyyy" value="<?= set_value('tgl_lahir'); ?>">
                  <?= form_error('tgl_lahir', '<small class="text-danger pl-3">', '</small>' )?>
                </div>

                <div class="form-group col-md-4">
                  <label for="sex" class="control-label">Jenis Kelamin <span class="text-danger">*</span> </label>
                  <select id="sex" name="sex" class="form-control" value="<?= set_value('sex') ?>" >
                    <option selected></option>
                    <option value="Laki-laki">Laki-laki</option>
                    <option value="Perempuan">Perempuan</option>
                  </select>
                  <?= form_error('sex', '<small class="text-danger pl-3">', '</small>'); ?>
                </div>

                <div class="form-group col-md-4">
                  <label for="no_hp" class="control-label">No HP <span class="text-danger">*</span> </label>
                   <input type="text" class="form-control" id="no_hp" name="no_hp" min_length="12" maxlength="12" placeholder="No telepon yang dapat dihubungi" value="<?= set_value('no_hp'); ?>">
                  <?= form_error('no_hp', '<small class="text-danger pl-3">', '</small>' )?>
                </div>

                <div class="form-group col-md-4">
                  <label for="pekerjaan" class="control-label">Pekerjaan <span class="text-danger">*</span> </label>
                  <input type="text" class="form-control" id="pekerjaan" name="pekerjaan" placeholder="Pekerjaan" value="<?= set_value('pekerjaan'); ?>">
                  <?= form_error('pekerjaan', '<small class="text-danger pl-3">', '</small>' )?>
                </div>

                <div class="form-group col-md-4">
                  <label for="alamat" class="control-label">Alamat <span class="text-danger">*</span> </label>
                  <input type="text" class="form-control" id="alamat" name="alamat" placeholder="Masukkan Alamat" value="<?= set_value('alamat'); ?>">
                  <?= form_error('alamat', '<small class="text-danger pl-3">', '</small>' )?>
                </div>


                <div class="form-group col-md-4">
                  <label for="kelurahan" class="control-label">Kelurahan <span class="text-danger">*</span> </label>
                  <input type="text" class="form-control" id="kelurahan" name="kelurahan" placeholder="Kelurahan sesuai alamat tinggal" value="<?= set_value('kelurahan'); ?>">
                  <?= form_error('kelurahan', '<small class="text-danger pl-3">', '</small>' )?>
                </div>

                <div class="form-group col-md-4">
                  <label for="kecamatan" class="control-label">Kecamatan <span class="text-danger">*</span> </label>
                  <input type="text" class="form-control" id="kecamatan" name="kecamatan" placeholder="Kecamatan sesuai alamat tinggal" value="<?= set_value('kecamatan'); ?>">
                  <?= form_error('kecamatan', '<small class="text-danger pl-3">', '</small>' )?>
                </div>

                <!-- Button Selanjutnya -->
                <div class="form-group"></div>
                <div class="form-group col-md-2 offset-md-10">
                  <a href="#tab-deskripsibangunan" class="btn btn-light btn-icon-split">
                    <span class="text">Selanjutnya</span>
                    <span class="icon text-gray-600">
                      <i class="fas fa-arrow-right"></i>
                    </span>
                  </a>
                </div>
              </div>

              <div class="col-md-12" id="tab-deskripsibangunan"></div>
            </div>
         </div>
       </div>
     </div>


     <div class="card mt-5 wow fadeInUp ml-3" id="get-started" style="visibility: visible; animation-name: fadeInUp;">
        <div class="card-body">
          <ul class="nav nav-tabs mb-3" id="pills-tab" role="tablist">
            <li class="nav-item">
              <a class="nav-link active" id="pills-dua-tab" data-toggle="pill" href="#pills-dua" role="tab" aria-controls="pills-dua" aria-selected="false">Deskripsi Bangunan</a>
            </li>
          </ul>
          <div class="tab-content" id="pills-tabContent">
            <!-- Tab Deskripsi Bangunan -->
            <div class="tab-pane fade show active" id="pills-dua" role="tabpanel" aria-labelledby="pills-dua-tab">
              <div class="form-row col-md-12">
                 <div class="form-group col-md-4">
                  <label for="struktur" class="control-label">Sistem struktur <span class="text-danger">*</span> </label>
                  <select id="struktur" name="struktur" class="form-control" value="<?= set_value('struktur') ?>" >
                    <option selected></option>
                    <option value="Rumah Dinding Tembok Terkekang">Rumah Dinding Tembok Terkekang</option>
                    <option value="Rumah Dinding Tembok">Rumah Dinding Tembok</option>
                    <option value="Rumah Dinding Kayu">Rumah Dinding Kayu</option>
                    <option value="Rumah Dinding Tembok Kolom Kayu">Rumah Dinding Tembok Kolom Kayu</option>
                  </select>
                  <?= form_error('struktur', '<small class="text-danger pl-3">', '</small>'); ?>
                </div>

                <div class="form-group col-md-4">
                  <label for="lokasi" class="control-label">Gambaran Lokasi <span class="text-danger">*</span> </label>
                  <select id="lokasi" name="lokasi" class="form-control" value="<?= set_value('lokasi') ?>" >
                    <option selected></option>
                    <option value="Risiko Rendah">Risiko Rendah</option>
                    <option value="Risiko Longsor">Risiko Risiko Longsor</option>
                    <option value="Risiko Tsunami">Risiko Tsunami</option>
                    <option value="Ground Failure">Ground Failure</option>
                  </select>
                  <?= form_error('lokasi', '<small class="text-danger pl-3">', '</small>'); ?>
                </div>

                <div class="form-group col-md-4">
                  <label for="latitude" class="control-label">Latitude <span class="text-danger">*</span> </label>
                 <input type="text" class="form-control" id="latitude" name="latitude" placeholder="Masukkan titik koordinat dengan benar" value="<?= set_value('latitude'); ?>">
                <?= form_error('latitude', '<small class="text-danger pl-3">', '</small>' )?>
                </div>

                <div class="form-group col-md-4">
                  <label for="longitude" class="control-label">Longitude <span class="text-danger">*</span> </label>
                 <input type="text" class="form-control" id="longitude" name="longitude" placeholder="Masukkan titik koordinat dengan benar" value="<?= set_value('longitude'); ?>">
                <?= form_error('longitude', '<small class="text-danger pl-3">', '</small>' )?>
                </div>

                <div class="form-group col-md-4">
                  <label for="kondisi" class="control-label">Kondisi Umum <span class="text-danger">*</span> </label>
                  <select id="kondisi" name="kondisi" class="form-control" value="<?= set_value('kondisi') ?>" >
                    <option selected></option>
                    <option value="Tegak">Tegak</option>
                    <option value="Miring (> 2° teramati dengan mudah)">Miring (> 2° teramati dengan mudah</option>
                  </select>
                  <?= form_error('kondisi', '<small class="text-danger pl-3">', '</small>'); ?>
                </div>

                 <div class="form-group col-md-4">
                  <label for="fondasi">i. Fondasi indikasi penurunan > 5 cm</label>
                  <select class="form-control" id="fondasi" name="fondasi" value="<?= set_value('fondasi') ?>">
                    <option selected></option>
                    <option value="Kurang dari 30%"> < 30% </option>
                    <option value="30-50%"> 30-50% </option>
                    <option value="Lebih dari 50%"> > 50% </option>
                  </select>
                  <?= form_error('fondasi', '<small class="text-danger pl-3">', '</small>'); ?>
                </div>

                <div class="form-group col-md-4">
                  <label for="dinding">ii. Dinding (retak > 6 mm)</label>
                  <select class="form-control" id="dinding" name="dinding" value="<?= set_value('dinding') ?>">
                    <option selected></option>
                    <option value="Kurang dari 30%"> < 30% </option>
                    <option value="30-50%"> 30-50% </option>
                    <option value="Lebih dari 50%"> > 50% </option>
                  </select>
                  <?= form_error('dinding', '<small class="text-danger pl-3">', '</small>'); ?>
                </div>

                <div class="form-group col-md-4">
                  <label for="rangka">iii. Rangka pengekang dinding (retak >1mm)</label>
                  <select class="form-control" id="rangka" name="rangka" value="<?= set_value('rangka') ?>">
                    <option selected></option>
                    <option value="Kurang dari 30%"> < 30% </option>
                    <option value="30-50%"> 30-50% </option>
                    <option value="Lebih dari 50%"> > 50% </option>
                  </select>
                  <?= form_error('rangka', '<small class="text-danger pl-3">', '</small>'); ?>
                </div>

                <div class="form-group col-md-4">
                  <label for="atap">iv. Rangka atap (bergeser/patah)</label>
                  <select class="form-control" id="atap" name="atap" value="<?= set_value('atap') ?>">
                    <option selected></option>
                    <option value="Kurang dari 30%"> < 30% </option>
                    <option value="30-50%"> 30-50% </option>
                    <option value="Lebih dari 50%"> > 50% </option>
                  </select>
                  <?= form_error('atap', '<small class="text-danger pl-3">', '</small>'); ?>
                </div>

                <div class="form-group col-md-4">
                  <label for="bantuan" class="control-label">Jenis Bantuan <span class="text-danger">*</span> </label>
                  <select id="bantuan" name="bantuan" class="form-control" value="<?= set_value('bantuan') ?>" >
                    <option selected></option>
                    <option value="Stimulan 1">Stimulan 1</option>
                    <option value="Stimulan 2">Stimulan 2</option>
                  </select>
                  <?= form_error('bantuan', '<small class="text-danger pl-3">', '</small>'); ?>
                </div>

                <div class="form-group col-md-4">
                  <label for="rusak" class="control-label">Kategori Kerusakan <span class="text-danger">*</span> </label>
                  <select id="rusak" name="rusak" class="form-control" value="<?= set_value('rusak') ?>" >
                    <option selected></option>
                    <option value="Rumah Ringan">Rusak Ringan</option>
                    <option value="Rusak Sedang">Rusak Sedang</option>
                    <option value="Rusak Berat">Rusak Berat</option>
                  </select>
                  <?= form_error('rusak', '<small class="text-danger pl-3">', '</small>'); ?>
                </div>

                <div class="form-group col-md-4">
                  <label for="status" class="control-label">Status Lahan <span class="text-danger">*</span> </label>
                  <select id="status" name="status" class="form-control" value="<?= set_value('status') ?>" >
                    <option selected></option>
                    <option value="Pribadi">Pribadi</option>
                    <option value="Kontrak">Kontrak</option>
                    <option value="Kost">Kost</option>
                  </select>
                  <?= form_error('status', '<small class="text-danger pl-3">', '</small>'); ?>
                </div>

                <div class="form-group col-md-12"></div>
                <div class="form-group col-md-2 offset-md-8">
                  <a href="#tab-cp" class="btn btn-light btn-icon-split">
                    <span class="icon text-gray-600">
                      <i class="fas fa-arrow-left"></i>
                    </span>
                    <span class="text">Kembali</span>
                  </a>
                </div>
                <div class="form-group col-md-2">
                  <a href="#tab-lampiran" class="btn btn-light btn-icon-split">
                    <span class="text">Selanjutnya</span>
                    <span class="icon text-gray-600">
                      <i class="fas fa-arrow-right"></i>
                    </span>
                  </a>
                </div>

                <div class="col-md-12" id="tab-lampiran"></div>
              </div>
            </div>
          </div>
       </div>
     </div>

     <div class="card mt-5 wow fadeInUp ml-3" id="get-started">
        <div class="card-body">
          <ul class="nav nav-tabs mb-3" id="pills-tab" role="tablist">
            <li class="nav-item">
              <a class="nav-link active" id="pills-tiga-tab" data-toggle="pill" href="#pills-tiga" role="tab" aria-controls="pills-tiga" aria-selected="false">Lampiran</a>
            </li>
          </ul>
          <div class="tab-content" id="pills-tabContent">
            <!-- Tab Lampiran -->
            <div class="tab-pane fade show active" id="pills-tiga" role="tabpanel" aria-labelledby="pills-tiga-tab">
              <div class="form-row col-md-12">
                <?php echo $this->session->flashdata('upload_error'); ?>
                <div class="form-group col-md-12">
                  <label for="foto" class="control-label">Foto Tampak Depan <span class="text-danger"> *</span> </label>
                  <input class="col-md-4 form-control" type="file" accept=".jpg, .png, .jpeg" id="foto" name="foto" value="<?= set_value('foto') ?>"/>
                </div>
                <div class="form-group col-md-12">
                  <label for="foto2" class="control-label">Foto Tampak Samping <span class="text-danger"> *</span> </label>
                  <input class="col-md-4 form-control" type="file" accept=".jpg, .png, .jpeg" id="foto2" name="foto2" value="<?= set_value('foto2') ?>"/>
                </div>
                <div class="col-md-12"></div>
                <div class="form-group col-md-12">
                  <label for="foto3" class="control-label">Foto Tampak Belakang <span class="text-danger"> *</span> </label>
                  <input class="col-md-4 form-control" type="file" accept=".jpg, .png, .jpeg" id="foto3" name="foto3" value="<?= set_value('foto3') ?>"/>
                </div>
                <div class="form-group col-md-12">
                  <label for="foto_kunjungan" class="control-label">Foto Kunjungan <span class="text-danger"> *</span> </label>
                  <input class="col-md-4 form-control" type="file" accept=".jpg, .png, .jpeg" id="foto_kunjungan" name="foto_kunjungan" value="<?= set_value('foto_kunjungan') ?>"/>
                </div>

                <div class="form-group col-md-12"></div>
                <div class="form-group col-md-2 offset-md-8">
                  <a href="#tab-cp" class="btn btn-light btn-icon-split">
                    <span class="icon text-gray-600">
                      <i class="fas fa-arrow-left"></i>
                    </span>
                    <span class="text">Kembali</span>
                  </a>
                </div>
                <div class="form-group col-md-2">
                  <a href="#tab-abp" class="btn btn-light btn-icon-split">
                    <span class="text">Selanjutnya</span>
                    <span class="icon text-gray-600">
                      <i class="fas fa-arrow-right"></i>
                    </span>
                  </a>
                </div>

                <div class="col-md-12" id="tab-abp"></div>
              </div>
            </div>
           </div>
       </div>
     </div>

    <div class="card mt-5 wow fadeInUp ml-3" id="get-started" style="visibility: visible; animation-name: fadeInUp;">
        <div class="card-body">
          <ul class="nav nav-tabs mb-3" id="pills-tab" role="tablist">
            <li class="nav-item">
              <a class="nav-link active" id="pills-dua-tab" data-toggle="pill" href="#pills-dua" role="tab" aria-controls="pills-dua" aria-selected="false">Data Pemeriksaan</a>
            </li>
          </ul>
          <div class="tab-content" id="pills-tabContent">
            <!-- Tab ABP  -->
            <div class="tab-pane fade show active" id="pills-dua" role="tabpanel" aria-labelledby="pills-dua-tab">
              <div class="form-row col-md-12">

                <div class="form-group col-md-4">
                    <label for="NIP" class="control-label">NIP <span class="text-danger">*</span> </label>
                    <input type="text" class="form-control" id="nip" name="nip" min_length="16" maxlength="16" placeholder="Nomor Identitas Pegawai Negeri Sipil" value="<?= $user['nip'] ?>" readonly>
                    <?= form_error('nip', '<small class="text-danger pl-3">', '</small>' )?>
                  </div>

                  <div class="form-group col-md-4">
                    <label for="name" class="control-label">Nama Asisten Bidang Perencanaan <span class="text-danger">*</span> </label>
                    <input type="text" class="form-control" id="name" name="name"  value="<?= $user['name']; ?>" readonly>
                    <?= form_error('name', '<small class="text-danger pl-3">', '</small>' )?>
                  </div>

                  <div class="form-group col-md-4">
                    <label for="tgl_periksa" class="control-label">Tanggal Pemeriksaan <span class="text-danger">*</span> </label>
                    <input type="date" id="tgl_periksa" name="tgl_periksa" class="form-control" placeholder="dd/mm/yyyy" value="<?= set_value('tgl_periksa'); ?>">
                    <?= form_error('tgl_periksa', '<small class="text-danger pl-3">', '</small>' )?>
                  </div>

                  <div class="form-group col-md-4">
                    <label for="catatan" class="control-label">Catatan</label>
                    <textarea class="form-control" id="catatan" name="catatan" placeholder="Catatan untuk Tim Penginput" value="<?= set_value('catatan'); ?>"></textarea>
                    <?= form_error('catatan', '<small class="text-danger pl-3">', '</small>' )?>
                  </div>

                  <div class="form-group col-md-4 mb-5">
                    <label for="waktu_periksa" class="control-label">Waktu Pemeriksaan <span class="text-danger">*</span> </label>
                    <input type="time" id="waktu_periksa" name="waktu_periksa" class="form-control"  value="<?= set_value('waktu_periksa'); ?>">
                    <?= form_error('waktu_periksa', '<small class="text-danger pl-3">', '</small>' )?>
                  </div>

                <div class="form-group col-md-2 offset-md-8">
                  <a href="#tab-lampiran" class="btn btn-light btn-icon-split">
                    <span class="icon text-gray-600">
                      <i class="fas fa-arrow-left"></i>
                    </span>
                    <span class="text">Kembali</span>
                  </a>
                </div>
            <button type="submit" name="tambah" class="btn btn-primary float-right">Tambah Data</button>
          </div>
        </div>
    </form>
  </div>
 </div>
</div>
</div>
</div>
</div>
</div>


<!-- Begin Page Content -->
<div class="container-fluid">


  <!-- Page Heading -->
  <div class="section-title text-center">
    <h1 class="h4 mb-4 text-gray-800"><?= $subtitle; ?></h1>
  </div>

  <!-- Seluruh Isi -->
  <div class="row">
    <!--ID TAB=CP -->
    <div class="col-md-12 mt-3">

        <?php if ($this->session->flashdata('flash')) : ?>
          <div class="alert alert-success alert-dismissible fade show" role="alert">Data Calon Penerima
            <strong>berhasil </strong><?= $this->session->flashdata('flash'); ?>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
    <?php endif; ?>

    <form class="user" enctype = "multipart/form-data" method="post"  action="<?= base_url('Penginput/verifikasi_calon')?>" role= "form">
      <input type="hidden" name="formpc-id" value="<?= $formpc['id']; ?>">
      <div class="card wow fadeInUp" id="get-started" style="visibility: visible; animation-name: fadeInUp;">
        <div class="card-header">
            <h5>
               <b><?= $formpc['nama'] ?></b>

               <span class="float-right detail-status">
                  <?= $formpc['status_pemeriksaan'] ?>
               </span>
             </h5>
            <p><?= $formpc['alamat'] ?></p>

        </div>

        <div class="card-body">

              <ul class="nav nav-tabs" id="pills-tab" role="tablist">
                <li class="nav-item">
                  <a class="nav-link active" id="pills-satu-tab" data-toggle="pill" href="#pills-satu" role="tab" aria-controls="pills-satu" aria-selected="true">Data calon penerima</a>
                </li>

                <li class="nav-item">
                  <a class="nav-link" id="pills-dua-tab" data-toggle="pill" href="#pills-dua" role="tab" aria-controls="pills-dua" aria-selected="true">Deskripsi bangunan</a>
                </li>

                <li class="nav-item">
                  <a class="nav-link" id="pills-tiga-tab" data-toggle="pill" href="#pills-tiga" role="tab" aria-controls="pills-tiga" aria-selected="true">Lampiran</a>
                </li>

                <li class="nav-item">
                  <a class="nav-link" id="pills-empat-tab" data-toggle="pill" href="#pills-empat" role="tab" aria-controls="pills-empat" aria-selected="true">Data pemeriksaan</a>
                </li>

                <li class="nav-item">
                  <a class="nav-link" id="pills-lima-tab" data-toggle="pill" href="#pills-lima" role="tab" aria-controls="pills-lima" aria-selected="true">Lokasi</a>
                </li>

              </ul>


              <br>
              <div class="tab-content" id="pills-tabContent">
                <!-- Tab Data Calon Penerima -->
                <div class="tab-pane fade show active" id="pills-satu" role="tabpanel" aria-labelledby="pills-satu-tab">
                  <div class="form-row col-md-12">

         <!--
                    <div class="form-group col-md-4">
                      <label for="NIK" class="control-label">NIK <span class="text-danger">*</span> </label>
                      <input type="text" class="form-control" id="nik" name="nik" min_length="16" maxlength="16"  value="<?= $formpc['nik']; ?>" readonly>
                    </div>

                    <div class="form-group col-md-4">
                      <label for="NOKK" class="control-label">Nomor KK (Kartu Keluarga) <span class="text-danger">*</span> </label>
                      <input type="text" class="form-control" id="nokk" name="nokk" min_length="16" maxlength="16"  value="<?= $formpc['nokk']; ?>" readonly>
                    </div>
           -->

                    <div class="form-group col-md-4">
                      <label for="nama" class="control-label">Nama Lengkap <span class="text-danger">*</span> </label>
                      <input type="text" class="form-control" id="nama" name="nama" value="<?= $formpc['nama'] ?>" readonly>
                    </div>

                    <div class="form-group col-md-4">
                      <label for="tgl_lahir" class="control-label">Tanggal Lahir <span class="text-danger">*</span> </label>
                      <input type="date" id="tgl_lahir" name="tgl_lahir" class="form-control" value="<?= $formpc['tgl_lahir']; ?>" readonly>
                   </div>

                    <div class="form-group col-md-4">
                      <label for="sex" class="control-label">Jenis Kelamin <span class="text-danger">*</span> </label>
                      <input id="sex" name="sex" class="form-control" value="<?= $formpc['sex'] ?>" readonly>
                    </div>

                    <div class="form-group col-md-4">
                      <label for="no_hp" class="control-label">No HP <span class="text-danger">*</span> </label>
                      <input type="text" class="form-control" id="no_hp" name="no_hp" min_length="12" maxlength="12" value="<?= $formpc['no_hp'] ?>" readonly>
                     </div>

                    <div class="form-group col-md-4">
                      <label for="pekerjaan" class="control-label">Pekerjaan <span class="text-danger">*</span> </label>
                      <input type="text" class="form-control" id="pekerjaan" name="pekerjaan" value="<?= $formpc['pekerjaan'] ?>" readonly>
                    </div>

                    <div class="form-group col-md-4">
                      <label for="alamat" class="control-label">Alamat <span class="text-danger">*</span> </label>
                      <input type="text" class="form-control" id="alamat" name="alamat" value="<?= $formpc['alamat'] ?>" readonly>
                    </div>


                    <div class="form-group col-md-4">
                      <label for="kelurahan" class="control-label">Kelurahan <span class="text-danger">*</span> </label>
                      <input type="text" class="form-control" id="kelurahan" name="kelurahan" value="<?= $formpc['kelurahan'] ?>" readonly>
                    </div>

                    <div class="form-group col-md-4">
                      <label for="kecamatan" class="control-label">Kecamatan <span class="text-danger">*</span> </label>
                      <input type="text" class="form-control" id="kecamatan" name="kecamatan" value="<?= $formpc['kecamatan'] ?>" readonly>
                    </div>

                  </div>

                  <div class="col-md-12" id="tab-deskripsibangunan"></div>
              </div>

              <!-- Tab content dua -->
              <div class="tab-pane fade" id="pills-dua" role="tabpanel" aria-labelledby="pills-dua-tab">
                  <div class="form-row col-md-12">
              <div class="form-group col-md-4">
               <label for="struktur" class="control-label">Sistem struktur <span class="text-danger">*</span> </label>
               <select id="struktur" name="struktur" class="form-control" value="<?= $formpc['struktur'] ?>" readonly>
               <?php foreach ($struktur as $st) : ?>
               <?php if ($st == $formpc['struktur']) :  ?>
               <option value="<?= $st; ?>" selected ><?= $st; ?></option>
               <?php else : ?>
               <option value="<?= $st; ?>"><?= $st; ?></option>
               <?php endif;  ?>
               <?php endforeach; ?>
               </select>
               <?= form_error('struktur', '<small class="text-danger pl-3">', '</small>'); ?>
             </div>

             <div class="form-group col-md-4">
               <label for="lokasi" class="control-label">Gambaran Lokasi <span class="text-danger">*</span> </label>
               <select id="lokasi" name="lokasi" class="form-control" value="<?= $formpc['lokasi'] ?>" readonly>
               <?php foreach ($lokasi as $l) : ?>
               <?php if ($l == $formpc['lokasi']) :  ?>
               <option value="<?= $l; ?>" selected ><?= $l; ?></option>
               <?php else : ?>
               <option value="<?= $l; ?>"><?= $l; ?></option>
               <?php endif;  ?>
               <?php endforeach; ?>
               </select>
               <?= form_error('lokasi', '<small class="text-danger pl-3">', '</small>'); ?>
             </div>

             <div class="form-group col-md-4">
               <label for="kondisi" class="control-label">Kondisi Umum <span class="text-danger">*</span> </label>
               <select id="kondisi" name="kondisi" class="form-control" value="<?= $formpc['kondisi'] ?>" readonly>
               <?php foreach ($kondisi as $k) : ?>
               <?php if ($k == $formpc['kondisi']) :  ?>
               <option value="<?= $k; ?>" selected ><?= $k; ?></option>
               <?php else : ?>
               <option value="<?= $k; ?>"><?= $k; ?></option>
               <?php endif;  ?>
               <?php endforeach; ?>
               </select>
               <?= form_error('kondisi', '<small class="text-danger pl-3">', '</small>'); ?>
             </div>

             <div class="form-group col-md-4">
               <label for="fondasi" class="control-label">i. Fondasi indikasi penurunan > 5 cm <span class="text-danger">*</span> </label>
               <select id="fondasi" name="fondasi" class="form-control" value="<?= $formpc['fondasi'] ?>" readonly>
               <?php foreach ($fondasi as $f) : ?>
               <?php if ($f == $formpc['fondasi']) :  ?>
               <option value="<?= $f; ?>" selected ><?= $f; ?></option>
               <?php else : ?>
               <option value="<?= $f; ?>"><?= $f; ?></option>
               <?php endif;  ?>
               <?php endforeach; ?>
               </select>
               <?= form_error('fondasi', '<small class="text-danger pl-3">', '</small>'); ?>
             </div>

             <div class="form-group col-md-4">
               <label for="dinding">ii. Dinding (retak > 6 mm) <span class="text-danger">*</span></label>
               <select id="dinding" name="dinding" class="form-control" value="<?= set_value('dinding') ?>" readonly>
               <?php foreach ($dinding as $d) : ?>
               <?php if ($d == $formpc['dinding']) :  ?>
               <option value="<?= $d; ?>" selected ><?= $d; ?></option>
               <?php else : ?>
               <option value="<?= $d; ?>"><?= $d; ?></option>
               <?php endif;  ?>
               <?php endforeach; ?>
               </select>
               <?= form_error('dinding', '<small class="text-danger pl-3">', '</small>'); ?>
             </div>

             <div class="form-group col-md-4">
               <label for="rangka">iii. Rangka pengekang dinding (retak >1mm)<span class="text-danger">*</span></label>
               <select id="rangka" name="rangka" class="form-control" value="<?= set_value('rangka') ?>" readonly>
               <?php foreach ($rangka as $ra) : ?>
               <?php if ($ra == $formpc['rangka']) :  ?>
               <option value="<?= $ra; ?>" selected ><?= $ra; ?></option>
               <?php else : ?>
               <option value="<?= $ra; ?>"><?= $ra; ?></option>
               <?php endif;  ?>
               <?php endforeach; ?>
               </select>
               <?= form_error('rangka', '<small class="text-danger pl-3">', '</small>'); ?>
             </div>

             <div class="form-group col-md-4">
               <label for="atap">iv. Rangka atap (bergeser/patah)</label>
               <select id="atap" name="atap" class="form-control" value="<?= set_value('atap') ?>" readonly>
               <?php foreach ($atap as $a) : ?>
               <?php if ($a == $formpc['atap']) :  ?>
               <option value="<?= $a; ?>" selected ><?= $a; ?></option>
               <?php else : ?>
               <option value="<?= $a; ?>"><?= $a; ?></option>
               <?php endif;  ?>
               <?php endforeach; ?>
               </select>
               <?= form_error('atap', '<small class="text-danger pl-3">', '</small>'); ?>
             </div>

             <div class="form-group col-md-4">
               <label for="bantuan" class="control-label">Jenis Bantuan <span class="text-danger">*</span> </label>
               <select id="bantuan" name="bantuan" class="form-control" value="<?= set_value('bantuan') ?>" readonly>
               <?php foreach ($bantuan as $ba) : ?>
               <?php if ($ba == $formpc['bantuan']) :  ?>
               <option value="<?= $ba; ?>" selected ><?= $ba; ?></option>
               <?php else : ?>
               <option value="<?= $ba; ?>"><?= $ba; ?></option>
               <?php endif;  ?>
               <?php endforeach; ?>
               </select>
               <?= form_error('bantuan', '<small class="text-danger pl-3">', '</small>'); ?>
             </div>

             <div class="form-group col-md-4">
               <label for="rusak" class="control-label">Kategori Kerusakan <span class="text-danger">*</span> </label>
               <select id="rusak" name="rusak" class="form-control" value="<?= set_value('rusak') ?>" readonly>
               <?php foreach ($rusak as $ru) : ?>
               <?php if ($ru == $formpc['ru']) :  ?>
               <option value="<?= $ru; ?>" selected ><?= $ru; ?></option>
               <?php else : ?>
               <option value="<?= $ru; ?>"><?= $ru; ?></option>
               <?php endif;  ?>
               <?php endforeach; ?>
               </select>
               <?= form_error('rusak', '<small class="text-danger pl-3">', '</small>'); ?>
             </div>

             <div class="form-group col-md-4">
               <label for="status" class="control-label">Status Lahan <span class="text-danger">*</span> </label>
               <select id="status" name="status" class="form-control" value="<?= set_value('status') ?>" readonly>
               <?php foreach ($status as $stat) : ?>
               <?php if ($stat == $formpc['status']) :  ?>
               <option value="<?= $stat; ?>" selected ><?= $stat; ?></option>
               <?php else : ?>
               <option value="<?= $stat; ?>"><?= $stat; ?></option>
               <?php endif;  ?>
               <?php endforeach; ?>
               </select>
               <?= form_error('status', '<small class="text-danger pl-3">', '</small>'); ?>
             </div>

                  </div>
              </div>
              <!-- End tab content dua -->

              <!-- Tab content tiga -->
              <div class="tab-pane fade" id="pills-tiga" role="tabpanel" aria-labelledby="pills-tiga-tab">
                  <div class="form-row col-md-12">
                      <div class="form-group col-md-12">
                        <label for="foto" class="control-label">Foto Tampak Depan <span class="text-danger"> *</span> </label>
                        <img class="img-lampiran rounded lazy" src="<?= base_url('assets/img/blank.png') ?>" data-src="<?= base_url('assets/img/rumah/'.$formpc['foto']) ?>">
                      </div>
                      <div class="form-group col-md-12">
                        <label for="foto2" class="control-label">Foto Tampak Samping <span class="text-danger"> *</span> </label>
                        <img class="img-lampiran rounded lazy" src="<?= base_url('assets/img/blank.png') ?>" data-src="<?= base_url('assets/img/rumah/'.$formpc['foto2']) ?>">
                      </div>
                      <div class="col-md-12"></div>
                      <div class="form-group col-md-12">
                        <label for="foto3" class="control-label">Foto Tampak Belakang <span class="text-danger"> *</span> </label>
                        <img class="img-lampiran rounded lazy" src="<?= base_url('assets/img/blank.png') ?>" data-src="<?= base_url('assets/img/rumah/'.$formpc['foto3']) ?>">
                      </div>
                      <div class="form-group col-md-12">
                        <label for="foto_kunjungan" class="control-label">Foto Kunjungan <span class="text-danger"> *</span> </label>
                        <img class="img-lampiran rounded lazy" src="<?= base_url('assets/img/blank.png') ?>" data-src="<?= base_url('assets/img/rumah/'.$formpc['foto_kunjungan']) ?>">
                      </div>

                      <div class="col-md-12" id="tab-abp"></div>
                  </div>
              </div>
              <!-- End tab content tiga -->

              <!-- Tab content empat -->
              <div class="tab-pane fade" id="pills-empat" role="tabpanel" aria-labelledby="pills-empat-tab">
                     <div class="form-row col-md-12">

                      <div class="form-group col-md-4">
                        <label for="NIP" class="control-label">NIP <span class="text-danger">*</span> </label>
                        <input type="text" class="form-control" id="nip" name="nip" min_length="16" maxlength="16" value="<?= $formpc['nip'] ?>" readonly>
                     </div>

                      <div class="form-group col-md-4">
                        <label for="name" class="control-label">Nama Asisten Bidang Perencanaan <span class="text-danger">*</span> </label>
                        <input type="text" class="form-control" id="name" name="name"  value="<?= $formpc['name']; ?>" readonly>
                      </div>

                      <div class="form-group col-md-4">
                        <label for="tgl_periksa" class="control-label">Tanggal Pemeriksaan <span class="text-danger">*</span> </label>
                        <input type="date" id="tgl_periksa" name="tgl_periksa" class="form-control" value="<?= $formpc['tgl_periksa']; ?>" readonly>
                      </div>

                      <div class="form-group col-md-4">
                        <label for="catatan" class="control-label">Catatan</label>
                        <textarea class="form-control" id="catatan" name="catatan" value="<?= $formpc['catatan'] ?>" readonly></textarea>
                        <?= form_error('catatan', '<small class="text-danger pl-3">', '</small>' )?>
                      </div>

                      <div class="form-group col-md-4 mb-5">
                        <label for="waktu_periksa" class="control-label">Waktu Pemeriksaan <span class="text-danger">*</span> </label>
                        <input type="time" id="waktu_periksa" name="waktu_periksa" class="form-control"  value="<?= $formpc['waktu_periksa']; ?>" readonly>
                      </div>

                  </div>

              </div>
              <!-- End tab content empat -->

              <!-- Tab content lima -->
              <div class="tab-pane fade" id="pills-lima" role="tabpanel" aria-labelledby="pills-lima-tab">
                  <div id="peta" style="width: 100%; height: 400px"></div>
              </div>
              <!-- End tab content lima -->
          </div>

        </div>
      </div>

    </div>
 </form>

       <div class="col-md-12 mt-3">

          <div class="card">
               <div class="card-body">
                     <div class="text-right">
                        <button type="button" id="btn-ditangguhkan" name="simpan" class="btn btn-primary mr-2" onclick="goBack()">Back</button>
                      </div>
               </div>
          </div>

       </div>
       <br>
   </div>
</div>


<link rel="stylesheet" href="https://unpkg.com/leaflet@1.5.1/dist/leaflet.css" />
<script src="https://unpkg.com/leaflet@1.5.1/dist/leaflet.js"></script>


 <script>
   var peta = null;

   $('.nav-tabs a').on('shown.bs.tab', function(event){
      var target = $(event.target).text(); //active tab
      if(target == 'Lokasi'){
         if(peta != null){
            return true;
         }

         let latitude = ("<?= $formpc['latitude']; ?>" == '') ? -4.424680621979349 : "<?= $formpc['latitude']; ?>";
         let longitude = ("<?= $formpc['longitude']; ?>" == '') ? 121.02790820527329 : "<?= $formpc['longitude']; ?>";
         let mapOptions = {
			      center: [latitude, longitude],
			      zoom: 13
		      }

	      peta = new L.map('peta', mapOptions);

	      L.tileLayer('https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token={accessToken}', {
		      attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors, <a href="https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, Imagery © <a href="https://www.mapbox.com/">Mapbox</a>',
		      maxZoom: 100,
		      id: 'mapbox.streets',
		      accessToken: 'pk.eyJ1IjoibWFwYm94IiwiYSI6ImNpejY4NXVycTA2emYycXBndHRqcmZ3N3gifQ.rJcFIG214AriISLbB6B5aw'
	      }).addTo(peta);

	      let marker = L.marker([latitude, longitude]).addTo(peta);
         peta.invalidateSize();

      }

   });

   $('.lazy').Lazy();
   $('#btn-ditangguhkan').click(function(){
      verifikasi('ditangguhkan');
   });
   $('#btn-verif').click(function(){
      verifikasi('setuju');
   });

   $('.nav-tabs a').on('shown.bs.tab', function(event){
     var x = $(event.target).text();         // active tab
     var y = $(event.relatedTarget).text();  // previous tab
   });

   function verifikasi(status){
      $('#verifikasi').val(status);
      $('#form-verifikasi').submit();
   }
 </script>

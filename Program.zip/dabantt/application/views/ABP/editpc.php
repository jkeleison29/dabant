<!-- Begin Page Content -->
<div class="container-fluid">


  <!-- Page Heading -->
  <div class="section-title text-center">
    <h1 class="h4 mb-4 text-gray-800"><?= $subtitle; ?></h1>
  </div>

  <!-- Seluruh Isi -->
  <div class="row">
    <!--ID TAB=CP -->
    <div class="col-md-12" id="tab-cp"></div>
    <div class="col-md-12 mt-3">

      <div class="col-md">
        <?php if ($this->session->flashdata('flash')) : ?>
          <div class="alert alert-success alert-dismissible fade show" role="alert">Data Calon Penerima
            <strong>berhasil </strong><?= $this->session->flashdata('flash'); ?>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
        </div>
      </div>
    <?php endif; ?>

    <form class="user" enctype = "multipart/form-data" method="post"  action="" role= "form">
      <input type="hidden" name="id" value="<?= $formpc['id']; ?>">
      <div class="card wow fadeInUp ml-3" id="get-started" style="visibility: visible; animation-name: fadeInUp;">
        <div class="card-body">
           <ul class="nav nav-tabs" id="pills-tab" role="tablist">
             <li class="nav-item">
               <a class="nav-link disabled active" id="pills-satu-tab" data-toggle="pill" href="#pills-satu" role="tab" aria-controls="pills-satu" aria-selected="true">Data Calon Penerima</a>
             </li>
           </ul>
           <br>
           <div class="tab-content" id="pills-tabContent">
             <!-- Tab Data Calon Penerima -->
             <div class="tab-pane fade show active" id="pills-satu" role="tabpanel" aria-labelledby="pills-satu-tab">
               <div class="form-row col-md-12">

                 <div class="form-group col-md-4">
                   <label for="NIK" class="control-label">NIK <span class="text-danger">*</span> </label>
                   <input type="text" class="form-control" id="nik" name="nik" min_length="16" maxlength="16"  value="<?= $formpc['nik']; ?>" readonly>
                   <?= form_error('nik', '<small class="text-danger pl-3">', '</small>' )?>
                 </div>

                 <div class="form-group col-md-4">
                   <label for="NOKK" class="control-label">Nomor KK (Kartu Keluarga) <span class="text-danger">*</span> </label>
                   <input type="text" class="form-control" id="nokk" name="nokk" min_length="16" maxlength="16"  value="<?= $formpc['nokk']; ?>">
                   <?= form_error('nokk', '<small class="text-danger pl-3">', '</small>' )?>
                 </div>

                 <div class="form-group col-md-4">
                   <label for="nama" class="control-label">Nama Lengkap <span class="text-danger">*</span> </label>
                   <input type="text" class="form-control" id="nama" name="nama" value="<?= $formpc['nama'] ?>">
                   <?= form_error('nama', '<small class="text-danger pl-3">', '</small>' )?>
                 </div>

                 <div class="form-group col-md-4">
                   <label for="tgl_lahir" class="control-label">Tanggal Lahir <span class="text-danger">*</span> </label>
                   <input type="date" id="tgl_lahir" name="tgl_lahir" class="form-control" value="<?= $formpc['tgl_lahir'] ?>">
                   <?= form_error('tgl_lahir', '<small class="text-danger pl-3">', '</small>' )?>
                 </div>

                 <div class="form-group col-md-4">
                   <label for="sex" class="control-label">Jenis Kelamin <span class="text-danger">*</span> </label>
                   <select id="sex" name="sex" class="form-control" value="<?= set_value('sex') ?>" >
                     <?php foreach ($sex as $jk) : ?>
                       <<?php if ($jk == $formpc['sex']) :  ?>
                       <option value="<?= $jk; ?>" selected ><?= $jk; ?></option>
                       <?php else : ?>
                         <option value="<?= $jk; ?>"><?= $jk; ?></option>
                       <?php endif;  ?>
                     <?php endforeach; ?>
                   </select>
                   <?= form_error('sex', '<small class="text-danger pl-3">', '</small>'); ?>
                 </div>

                 <div class="form-group col-md-4">
                   <label for="no_hp" class="control-label">No HP <span class="text-danger">*</span> </label>
                   <input type="text" class="form-control" id="no_hp" name="no_hp" min_length="12" maxlength="12" value="<?= $formpc['no_hp'] ?>">
                   <?= form_error('no_hp', '<small class="text-danger pl-3">', '</small>' )?>
                 </div>

                 <div class="form-group col-md-4">
                   <label for="pekerjaan" class="control-label">Pekerjaan <span class="text-danger">*</span> </label>
                   <input type="text" class="form-control" id="pekerjaan" name="pekerjaan" value="<?= $formpc['pekerjaan'] ?>">
                   <?= form_error('pekerjaan', '<small class="text-danger pl-3">', '</small>' )?>
                 </div>

                 <div class="form-group col-md-4">
                   <label for="alamat" class="control-label">Alamat <span class="text-danger">*</span> </label>
                   <input type="text" class="form-control" id="alamat" name="alamat" value="<?= $formpc['alamat'] ?>">
                   <?= form_error('alamat', '<small class="text-danger pl-3">', '</small>' )?>
                 </div>


                 <div class="form-group col-md-4">
                   <label for="kelurahan" class="control-label">Kelurahan <span class="text-danger">*</span> </label>
                   <input type="text" class="form-control" id="kelurahan" name="kelurahan" value="<?= $formpc['kelurahan'] ?>">
                   <?= form_error('kelurahan', '<small class="text-danger pl-3">', '</small>' )?>
                 </div>

                 <div class="form-group col-md-4">
                   <label for="kecamatan" class="control-label">Kecamatan <span class="text-danger">*</span> </label>
                   <input type="text" class="form-control" id="kecamatan" name="kecamatan" value="<?= $formpc['kecamatan'] ?>">
                   <?= form_error('kecamatan', '<small class="text-danger pl-3">', '</small>' )?>
                 </div>

                 <!-- Button Selanjutnya -->
                 <div class="form-group"></div>
                 <div class="form-group col-md-2 offset-md-10">
                   <a href="#tab-deskripsibangunan" class="btn btn-light btn-icon-split">
                     <span class="text">Selanjutnya</span>
                     <span class="icon text-gray-600">
                       <i class="fas fa-arrow-right"></i>
                     </span>
                   </a>
                 </div>
               </div>

               <div class="col-md-12" id="tab-deskripsibangunan"></div>
             </div>
          </div>
        </div>
      </div>

      <div class="card mt-5 wow fadeInUp ml-3" id="get-started" style="visibility: visible; animation-name: fadeInUp;">
        <div class="card-body">
           <ul class="nav nav-tabs mb-3" id="pills-tab" role="tablist">
             <li class="nav-item">
               <a class="nav-link active" id="pills-dua-tab" data-toggle="pill" href="#pills-dua" role="tab" aria-controls="pills-dua" aria-selected="false">Deskripsi Bangunan</a>
             </li>
           </ul>
           <div class="tab-content" id="pills-tabContent">
             <!-- Tab Deskripsi Bangunan -->
             <div class="tab-pane fade show active" id="pills-dua" role="tabpanel" aria-labelledby="pills-dua-tab">
               <div class="form-row col-md-12">
                 <div class="form-group col-md-4">
                   <label for="struktur" class="control-label">Sistem struktur <span class="text-danger">*</span> </label>
                   <select id="struktur" name="struktur" class="form-control" value="<?= set_value('struktur') ?>" >
                   <?php foreach ($struktur as $st) : ?>
                   <?php if ($st == $formpc['struktur']) :  ?>
                   <option value="<?= $st; ?>" selected ><?= $st; ?></option>
                   <?php else : ?>
                   <option value="<?= $st; ?>"><?= $st; ?></option>
                   <?php endif;  ?>
                   <?php endforeach; ?>
                   </select>
                   <?= form_error('struktur', '<small class="text-danger pl-3">', '</small>'); ?>
                 </div>

                 <div class="form-group col-md-4">
                   <label for="lokasi" class="control-label">Gambaran Lokasi <span class="text-danger">*</span> </label>
                   <select id="lokasi" name="lokasi" class="form-control" value="<?= set_value('lokasi') ?>" >
                   <?php foreach ($lokasi as $l) : ?>
                   <?php if ($l == $formpc['lokasi']) :  ?>
                   <option value="<?= $l; ?>" selected ><?= $l; ?></option>
                   <?php else : ?>
                   <option value="<?= $l; ?>"><?= $l; ?></option>
                   <?php endif;  ?>
                   <?php endforeach; ?>
                   </select>
                   <?= form_error('lokasi', '<small class="text-danger pl-3">', '</small>'); ?>
                 </div>

                <div class="form-group col-md-4">
                  <label for="latitude" class="control-label">Latitude <span class="text-danger">*</span> </label>
                 <input type="text" class="form-control" id="latitude" name="latitude" placeholder="Masukkan titik koordinat dengan benar" value="<?= $formpc['latitude'] ?>">
                <?= form_error('latitude', '<small class="text-danger pl-3">', '</small>' )?>
                </div>

                <div class="form-group col-md-4">
                  <label for="longitude" class="control-label">Longitude <span class="text-danger">*</span> </label>
                 <input type="text" class="form-control" id="longitude" name="longitude" placeholder="Masukkan titik koordinat dengan benar" value="<?= $formpc['longitude'] ?>">
                <?= form_error('longitude', '<small class="text-danger pl-3">', '</small>' )?>
                </div>

                 <div class="form-group col-md-4">
                   <label for="kondisi" class="control-label">Kondisi Umum <span class="text-danger">*</span> </label>
                   <select id="kondisi" name="kondisi" class="form-control" value="<?= set_value('kondisi') ?>" >
                   <?php foreach ($kondisi as $k) : ?>
                   <?php if ($k == $formpc['kondisi']) :  ?>
                   <option value="<?= $k; ?>" selected ><?= $k; ?></option>
                   <?php else : ?>
                   <option value="<?= $k; ?>"><?= $k; ?></option>
                   <?php endif;  ?>
                   <?php endforeach; ?>
                   </select>
                   <?= form_error('kondisi', '<small class="text-danger pl-3">', '</small>'); ?>
                 </div>

                 <div class="form-group col-md-4">
                   <label  for="fondasi">i. Fondasi indikasi penurunan > 5 cm</label>
                   <select class="form-control" id="fondasi" name="fondasi" value="<?= set_value('fondasi') ?>">
                   <?php foreach ($fondasi as $f) : ?>
                   <?php if ($f == $formpc['fondasi']) :  ?>
                   <option value="<?= $f; ?>" selected ><?= $f; ?></option>
                   <?php else : ?>
                   <option value="<?= $f; ?>"><?= $f; ?></option>
                   <?php endif;  ?>
                   <?php endforeach; ?>
                   </select>
                   <?= form_error('fondasi', '<small class="text-danger pl-3">', '</small>'); ?>
                 </div>

                 <div class="form-group col-md-4">
                   <label  for="dinding">ii. Dinding (retak > 6 mm)</label>
                   <select class="form-control" id="dinding" name="dinding" value="<?= set_value('dinding') ?>">
                   <?php foreach ($dinding as $d) : ?>
                   <?php if ($d == $formpc['dinding']) :  ?>
                   <option value="<?= $d; ?>" selected ><?= $d; ?></option>
                   <?php else : ?>
                   <option value="<?= $d; ?>"><?= $d; ?></option>
                   <?php endif;  ?>
                   <?php endforeach; ?>
                   </select>
                   <?= form_error('dinding', '<small class="text-danger pl-3">', '</small>'); ?>
                 </div>

                 <div class="form-group col-md-4">
                   <label  for="rangka">iii. Rangka pengekang dinding (retak >1mm)</label>
                   <select class="form-control" id="rangka" name="rangka" value="<?= set_value('rangka') ?>">
                   <?php foreach ($rangka as $ra) : ?>
                   <?php if ($ra == $formpc['rangka']) :  ?>
                   <option value="<?= $ra; ?>" selected ><?= $ra; ?></option>
                   <?php else : ?>
                   <option value="<?= $ra; ?>"><?= $ra; ?></option>
                   <?php endif;  ?>
                   <?php endforeach; ?>
                   </select>
                   <?= form_error('rangka', '<small class="text-danger pl-3">', '</small>'); ?>
                 </div>

                 <div class="form-group col-md-4">
                   <label for="atap">iv. Rangka atap (bergeser/patah)</label>
                   <select class="form-control" id="atap" name="atap" value="<?= set_value('atap') ?>">
                   <?php foreach ($atap as $a) : ?>
                   <?php if ($a == $formpc['atap']) :  ?>
                   <option value="<?= $a; ?>" selected ><?= $a; ?></option>
                   <?php else : ?>
                   <option value="<?= $a; ?>"><?= $a; ?></option>
                   <?php endif;  ?>
                   <?php endforeach; ?>
                   </select>
                   <?= form_error('atap', '<small class="text-danger pl-3">', '</small>'); ?>
                 </div>

                 <div class="form-group col-md-4">
                   <label for="bantuan" class="control-label">Jenis Bantuan <span class="text-danger">*</span> </label>
                   <select id="bantuan" name="bantuan" class="form-control" value="<?= set_value('bantuan') ?>" >
                   <?php foreach ($bantuan as $ba) : ?>
                   <?php if ($ba == $formpc['bantuan']) :  ?>
                   <option value="<?= $ba; ?>" selected ><?= $ba; ?></option>
                   <?php else : ?>
                   <option value="<?= $ba; ?>"><?= $ba; ?></option>
                   <?php endif;  ?>
                   <?php endforeach; ?>
                   </select>
                   <?= form_error('bantuan', '<small class="text-danger pl-3">', '</small>'); ?>
                 </div>

                 <div class="form-group col-md-4">
                   <label for="rusak" class="control-label">Kategori Kerusakan <span class="text-danger">*</span> </label>
                   <select id="rusak" name="rusak" class="form-control" value="<?= set_value('rusak') ?>" >
                   <?php foreach ($rusak as $ru) : ?>
                   <?php if ($ru == $formpc['ru']) :  ?>
                   <option value="<?= $ru; ?>" selected ><?= $ru; ?></option>
                   <?php else : ?>
                   <option value="<?= $ru; ?>"><?= $ru; ?></option>
                   <?php endif;  ?>
                   <?php endforeach; ?>
                   </select>
                   <?= form_error('rusak', '<small class="text-danger pl-3">', '</small>'); ?>
                 </div>

                 <div class="form-group col-md-4">
                   <label for="status" class="control-label">Status Lahan <span class="text-danger">*</span> </label>
                   <select id="status" name="status" class="form-control" value="<?= set_value('status') ?>" >
                   <?php foreach ($status as $stat) : ?>
                   <?php if ($stat == $formpc['status']) :  ?>
                   <option value="<?= $stat; ?>" selected ><?= $stat; ?></option>
                   <?php else : ?>
                   <option value="<?= $stat; ?>"><?= $stat; ?></option>
                   <?php endif;  ?>
                   <?php endforeach; ?>
                   </select>
                   <?= form_error('status', '<small class="text-danger pl-3">', '</small>'); ?>
                 </div>

                 <div class="form-group col-md-12"></div>
                 <div class="form-group col-md-2 offset-md-8">
                   <a href="#tab-cp" class="btn btn-light btn-icon-split">
                     <span class="icon text-gray-600">
                       <i class="fas fa-arrow-left"></i>
                     </span>
                     <span class="text">Kembali</span>
                   </a>
                 </div>
                 <div class="form-group col-md-2">
                   <a href="#tab-lampiran" class="btn btn-light btn-icon-split">
                     <span class="text">Selanjutnya</span>
                     <span class="icon text-gray-600">
                       <i class="fas fa-arrow-right"></i>
                     </span>
                   </a>
                 </div>

                 <div class="col-md-12" id="tab-lampiran"></div>
               </div>
            </div>
          </div>
        </div>
      </div>


     <div class="card mt-5 wow fadeInUp ml-3" id="get-started">
         <div class="card-body">
             <ul class="nav nav-tabs mb-3" id="pills-tab" role="tablist">
               <li class="nav-item">
                 <a class="nav-link active" id="pills-tiga-tab" data-toggle="pill" href="#pills-tiga" role="tab" aria-controls="pills-tiga" aria-selected="false">Lampiran</a>
               </li>
             </ul>
             <div class="tab-content" id="pills-tabContent">
               <!-- Tab Lampiran -->
               <div class="tab-pane fade show active" id="pills-tiga" role="tabpanel" aria-labelledby="pills-tiga-tab">
                    <div class="form-row col-md-12">
                      <div class="form-group col-md-12">
                       <h6>Foto diunggah</h6>
                       <hr>
                      </div>
                      <div class="form-group col-md-6">
                        <label for="foto" class="control-label">Foto Tampak Depan <span class="text-danger"> *</span> </label>
                        <img class="img-lampiran rounded lazy" src="<?= base_url('assets/img/blank.png') ?>" data-src="<?= base_url('assets/img/rumah/'.$formpc['foto']) ?>">
                      </div>
                      <div class="form-group col-md-6">
                        <label for="foto2" class="control-label">Foto Tampak Samping <span class="text-danger"> *</span> </label>
                        <img class="img-lampiran rounded lazy" src="<?= base_url('assets/img/blank.png') ?>" data-src="<?= base_url('assets/img/rumah/'.$formpc['foto2']) ?>">
                      </div>
                      <div class="col-md-12"></div>
                      <div class="form-group col-md-6">
                        <label for="foto3" class="control-label">Foto Tampak Belakang <span class="text-danger"> *</span> </label>
                        <img class="img-lampiran rounded lazy" src="<?= base_url('assets/img/blank.png') ?>" data-src="<?= base_url('assets/img/rumah/'.$formpc['foto3']) ?>">
                      </div>
                      <div class="form-group col-md-6">
                        <label for="foto_kunjungan" class="control-label">Foto Kunjungan <span class="text-danger"> *</span> </label>
                        <img class="img-lampiran rounded lazy" src="<?= base_url('assets/img/blank.png') ?>" data-src="<?= base_url('assets/img/rumah/'.$formpc['foto_kunjungan']) ?>">
                      </div>

                      <div class="col-md-12" id="tab-abp"></div>
                  </div>

                 <hr>

                 <div class="form-row col-md-12">
                   <?php echo $this->session->flashdata('upload_error'); ?>
                   <div class="form-group col-md-12">
                     <label for="foto" class="control-label">Foto Tampak Depan <span class="text-danger"> *</span> </label>
                     <input class="col-md-4 form-control" type="file" accept=".jpg, .png, .jpeg" id="foto" name="foto" value="<?= set_value('foto') ?>"/>
                   </div>
                   <div class="form-group col-md-12">
                     <label for="foto2" class="control-label">Foto Tampak Samping <span class="text-danger"> *</span> </label>
                     <input class="col-md-4 form-control" type="file" accept=".jpg, .png, .jpeg" id="foto2" name="foto2" value="<?= set_value('foto2') ?>"/>
                   </div>
                   <div class="col-md-12"></div>
                   <div class="form-group col-md-12">
                     <label for="foto3" class="control-label">Foto Tampak Belakang <span class="text-danger"> *</span> </label>
                     <input class="col-md-4 form-control" type="file" accept=".jpg, .png, .jpeg" id="foto3" name="foto3" value="<?= set_value('foto3') ?>"/>
                   </div>
                   <div class="form-group col-md-12">
                     <label for="foto_kunjungan" class="control-label">Foto Kunjungan <span class="text-danger"> *</span> </label>
                     <input class="col-md-4 form-control" type="file" accept=".jpg, .png, .jpeg" id="foto_kunjungan" name="foto_kunjungan" value="<?= set_value('foto_kunjungan') ?>"/>
                   </div>

                   <div class="form-group col-md-12"></div>
                   <div class="form-group col-md-2 offset-md-8">
                     <a href="#tab-cp" class="btn btn-light btn-icon-split">
                       <span class="icon text-gray-600">
                         <i class="fas fa-arrow-left"></i>
                       </span>
                       <span class="text">Kembali</span>
                     </a>
                   </div>
                   <div class="form-group col-md-2">
                     <a href="#tab-abp" class="btn btn-light btn-icon-split">
                       <span class="text">Selanjutnya</span>
                       <span class="icon text-gray-600">
                         <i class="fas fa-arrow-right"></i>
                       </span>
                     </a>
                   </div>

                   <div class="col-md-12" id="tab-abp"></div>
                  </div>
              </div>
            </div>
          </div>
        </div>

      <div class="card mt-5 wow fadeInUp ml-3" id="get-started" style="visibility: visible; animation-name: fadeInUp;">
          <div class="card-body">
             <ul class="nav nav-tabs mb-3" id="pills-tab" role="tablist">
               <li class="nav-item">
                 <a class="nav-link active" id="pills-dua-tab" data-toggle="pill" href="#pills-dua" role="tab" aria-controls="pills-dua" aria-selected="false">Data Pemeriksaan</a>
               </li>
             </ul>
             <div class="tab-content" id="pills-tabContent">
               <!-- Tab ABP  -->
               <div class="tab-pane fade show active" id="pills-dua" role="tabpanel" aria-labelledby="pills-dua-tab">
                 <div class="form-row col-md-12">

                   <div class="form-group col-md-4">
                     <label for="NIP" class="control-label">NIP <span class="text-danger">*</span> </label>
                     <input type="text" class="form-control" id="nip" name="nip" min_length="16" maxlength="16" value="<?= $formpc['nip'] ?>" readonly>
                     <?= form_error('nip', '<small class="text-danger pl-3">', '</small>' )?>
                   </div>

                   <div class="form-group col-md-4">
                     <label for="name" class="control-label">Nama Asisten Bidang Perencanaan <span class="text-danger">*</span> </label>
                     <input type="text" class="form-control" id="name" name="name"  value="<?= $user['name']; ?>" readonly>
                     <?= form_error('name', '<small class="text-danger pl-3">', '</small>' )?>
                   </div>

                   <div class="form-group col-md-4">
                     <label for="tgl_periksa" class="control-label">Tanggal Pemeriksaan <span class="text-danger">*</span> </label>
                     <input type="date" id="tgl_periksa" name="tgl_periksa" class="form-control" placeholder="dd/mm/yyyy" value="<?= $formpc['tgl_periksa']; ?>">
                     <?= form_error('tgl_periksa', '<small class="text-danger pl-3">', '</small>' )?>
                   </div>

                   <div class="form-group col-md-4">
                     <label for="catatan" class="control-label">Catatan</label>
                     <textarea class="form-control" id="catatan" name="catatan" value="<?= $formpc['catatan'] ?>"></textarea>
                     <?= form_error('catatan', '<small class="text-danger pl-3">', '</small>' )?>
                   </div>

                   <div class="form-group col-md-4 mb-5">
                     <label for="waktu_periksa" class="control-label">Waktu Pemeriksaan <span class="text-danger">*</span> </label>
                     <input type="time" id="waktu_periksa" name="waktu_periksa" class="form-control"  value="<?= $formpc['waktu_periksa']; ?>">
                     <?= form_error('waktu_periksa', '<small class="text-danger pl-3">', '</small>' )?>
                   </div>

                   <div class="form-group col-md-2 offset-md-8">
                     <a href="#tab-lampiran" class="btn btn-light btn-icon-split">
                       <span class="icon text-gray-600">
                         <i class="fas fa-arrow-left"></i>
                       </span>
                       <span class="text">Kembali</span>
                     </a>
                   </div>

                    <div class="form-group offset-md-12">
                    <button type="submit" name="simpan" class="btn btn-primary float-right">Simpan</button>
                   </div>
               </div>
         </form>
      </div>
    </div>
   </div>
  </div>
</div>
</div>
</div>
</div>

 <script>
   $('.lazy').Lazy();
 </script>

<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <!-- Custom fonts for this template-->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

  <!-- Custom styles for this template-->
  <link href="css/sb-admin-2.min.css" rel="stylesheet">
</head>

<div class="col-md">
  <?php if ($this->session->flashdata('flash')) : ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">Data Calon Penerima
      <strong>berhasil </strong><?= $this->session->flashdata('flash'); ?>
      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
      </button>
    </div>
  </div>
</div>
<?php endif; ?>



<div class="row">
  <div class="content-table ml-3">
    <div class="card">
      <div class="card-body">
            <nav>
              <div class="nav nav-tabs" id="nav-tab" role="tablist">
                <a class="nav-item nav-link active" id="nav-home-tab" data-toggle="tab" href="#semua" role="tab" aria-controls="nav-home" aria-selected="true">Semua</a>
                <a class="nav-item nav-link" id="nav-belum-validasi-tab" data-toggle="tab" href="#belum-validasi" role="tab" aria-controls="nav-validasi" aria-selected="false">Belum divalidasi</a>
                <a class="nav-item nav-link" id="nav-validasi-tab" data-toggle="tab" href="#sudah-validasi" role="tab" aria-controls="nav-validasi" aria-selected="false">Sudah divalidasi</a>
                <a class="nav-item nav-link" id="nav-validasi-tab" data-toggle="tab" href="#ditangguhkan" role="tab" aria-controls="nav-ditangguhkan" aria-selected="false">Ditangguhkan</a>
              </div>
            </nav>
            
            <div class="tab-content" id="nav-tabContent">
               <div class="tab-pane p-3 fade show active" id="semua" role="tabpanel" aria-labelledby="nav-home-tab">
                     <table class="table table-hover" id="tabel-semua">
                        <thead>
                          <tr>
                            <th scope="col">#</th>
                            <th><center scope="col">NIK</center></th>
                            <th><center scope="col">Nama Lengkap</center></th>
                            <th><center scope="col">Alamat</center></th>
                            <th><center scope="col">Tgl Pemeriksaan</center></th>
                            <th><center scope="col">Status</center></th>
                            <th><center scope="col">Action</center></th>
                          </tr>
                        </thead>
                        <tbody>
                          <?php

                          foreach ($formpc as $f) : ?>
                          <tr>
                            <td></td>
                              <td><?= $f->nik ?></td>
                              <td><center><?= $f->nama ?></center></td>
                              <td><center><?= $f->alamat ?></center></td>
                              <td><center><?= $f->tgl_periksa ?></center></td>
                              <td><?= $f->status_pemeriksaan ?></td>
                              <td>
                                 
                                 <?php if($f->status_pemeriksaan == 'Belum diajukan') {?>
                                    <a href="<?= base_url(); ?>ABP/editpc/<?= $f->id ?>" class="badge badge-success">Edit</a>
                                   <?php } else {?>
                                     <a  href="javascript:void(0);" class="badge badge-secondary">Edit</a>
                                   <?php }?>
                                

                                  <a href="<?= base_url(); ?>ABP/detailpc/<?= $f->id ?>"
                                    class="badge badge-info">Detail</a>

                                   <?php if($f->status_pemeriksaan == 'Belum diajukan') {?>
                                    <a href="<?= base_url(); ?>ABP/ajukanpc/<?= $f->id ?>" class="badge badge-warning" onclick="return confirm('Apa anda yakin ingin mengajukan?')">Ajukan</a>
                                   <?php } else {?>
                                     <a  href="javascript:void(0);" class="badge badge-secondary">Ajukan</a>
                                   <?php }?>
                                   
                                      <a href="<?= base_url(); ?>ABP/formrab?id=<?= $f->id ?>" class="badge badge-primary">RAB
                                    </a> 
                                       
                                    <?php if($f->status_pemeriksaan == 'Belum diajukan') {?>
                                         <a href="<?= base_url(); ?>ABP/deletepc/<?= $f->id ?>" class="badge badge-danger" onclick="return confirm('Apa anda yakin ingin menghapus data?')">Delete</a>
                                   <?php } else {?>
                                     <a  href="javascript:void(0);" class="badge badge-secondary">Delete</a>
                                   <?php }?>
                                    
                                      </td>

                                    </tr>
                                  <?php endforeach ; ?>
                                </table>
                              </tbody>
                            </table>
               </div>
               
               <div class="tab-pane p-3 fade" id="belum-validasi" role="tabpanel" aria-labelledby="nav-belum-validasi-tab">
                  <table class="table table-hover" id="tabel-belum-validasi">
                        <thead>
                          <tr>
                            <th scope="col">#</th>
                            <th><center scope="col">NIK</center></th>
                            <th><center scope="col">Nama Lengkap</center></th>
                            <th><center scope="col">Alamat</center></th>
                            <th><center scope="col">Tgl Pemeriksaan</center></th>

                            <th><center scope="col">Status</center></th>
                            <th><center scope="col">Action</center></th>
                          </tr>
                        </thead>
                        <tbody>
                          <?php

                          foreach ($formpc_tahap_validasi as $f) : ?>
                          <tr>
                            <td></td>
                              <td><?= $f->nik ?></td>
                              <td><center><?= $f->nama ?></center></td>
                              <td><center><?= $f->alamat ?></center></td>
                              <td><center><?= $f->tgl_periksa ?></center></td>
                              <td><?= $f->status_pemeriksaan ?></td>
                              <td>
<?php if($f->status_pemeriksaan == 'Belum diajukan') {?>
                                    <a href="<?= base_url(); ?>ABP/editpc/<?= $f->id ?>" class="badge badge-success">Edit</a>
                                   <?php } else {?>
                                     <a  href="javascript:void(0);" class="badge badge-secondary">Edit</a>
                                   <?php }?>
                                

                                  <a href="<?= base_url(); ?>ABP/detailpc/<?= $f->id ?>"
                                    class="badge badge-info">Detail</a>

                                   <?php if($f->status_pemeriksaan == 'Belum diajukan') {?>
                                    <a href="<?= base_url(); ?>ABP/ajukanpc/<?= $f->id ?>" class="badge badge-warning" onclick="return confirm('Apa anda yakin ingin mengajukan?')">Ajukan</a>
                                   <?php } else {?>
                                     <a  href="javascript:void(0);" class="badge badge-secondary">Ajukan</a>
                                   <?php }?>
                                   
                                      <a href="<?= base_url(); ?>ABP/formrab?id=<?= $f->id ?>" class="badge badge-primary">RAB
                                    </a> 
                                       
                                    <?php if($f->status_pemeriksaan == 'Belum diajukan') {?>
                                         <a href="<?= base_url(); ?>ABP/deletepc/<?= $f->id ?>" class="badge badge-danger" onclick="return confirm('Apa anda yakin ingin menghapus data?')">Delete</a>
                                   <?php } else {?>
                                     <a  href="javascript:void(0);" class="badge badge-secondary">Delete</a>
                                   <?php }?>
                                      </td>

                                    </tr>
                                  <?php endforeach ; ?>
                                </table>
                              </tbody>
                            </table>
               </div>
               
               <div class="tab-pane p-3 fade" id="sudah-validasi" role="tabpanel" aria-labelledby="nav-validasi-tab">
                     <table class="table table-hover" id="tabel-valid">
                        <thead>
                          <tr>
                            <th scope="col">#</th>
                            <th><center scope="col">NIK</center></th>
                            <th><center scope="col">Nama Lengkap</center></th>
                            <th><center scope="col">Alamat</center></th>
                            <th><center scope="col">Tgl Pemeriksaan</center></th>
                            <th><center scope="col">Status</center></th>
                            <th><center scope="col">Action</center></th>
                          </tr>
                        </thead>
                        <tbody>
                          <?php

                          foreach ($formpc_valid as $f) : ?>
                          <tr>
                            <td></td>
                              <td><?= $f->nik ?></td>
                              <td><center><?= $f->nama ?></center></td>
                              <td><center><?= $f->alamat ?></center></td>
                              <td><center><?= $f->tgl_periksa ?></center></td>
                              <td><?= $f->status_pemeriksaan ?></td>
                              <td>
                                 <?php if($f->status_pemeriksaan == 'Belum diajukan') {?>
                                    <a href="<?= base_url(); ?>ABP/editpc/<?= $f->id ?>" class="badge badge-success">Edit</a>
                                   <?php } else {?>
                                     <a  href="javascript:void(0);" class="badge badge-secondary">Edit</a>
                                   <?php }?>
                                

                                  <a href="<?= base_url(); ?>ABP/detailpc/<?= $f->id ?>"
                                    class="badge badge-info">Detail</a>

                                   <?php if($f->status_pemeriksaan == 'Belum diajukan') {?>
                                    <a href="<?= base_url(); ?>ABP/ajukanpc/<?= $f->id ?>" class="badge badge-warning" onclick="return confirm('Apa anda yakin ingin mengajukan?')">Ajukan</a>
                                   <?php } else {?>
                                     <a  href="javascript:void(0);" class="badge badge-secondary">Ajukan</a>
                                   <?php }?>
                                   
                                      <a href="<?= base_url(); ?>ABP/formrab?id=<?= $f->id ?>" class="badge badge-primary">RAB
                                    </a> 
                                       
                                    <?php if($f->status_pemeriksaan == 'Belum diajukan') {?>
                                         <a href="<?= base_url(); ?>ABP/deletepc/<?= $f->id ?>" class="badge badge-danger" onclick="return confirm('Apa anda yakin ingin menghapus data?')">Delete</a>
                                   <?php } else {?>
                                     <a  href="javascript:void(0);" class="badge badge-secondary">Delete</a>
                                   <?php }?>
                                      </td>

                                    </tr>
                                  <?php endforeach ; ?>
                                </table>
                              </tbody>
                            </table>
               </div>
               
               <div class="tab-pane p-3 fade" id="ditangguhkan" role="tabpanel" aria-labelledby="nav-ditangguhkan-tab">
                     <table class="table table-hover" id="tabel-ditangguhkan">
                        <thead>
                          <tr>
                            <th scope="col">#</th>
                            <th><center scope="col">NIK</center></th>
                            <th><center scope="col">Nama Lengkap</center></th>
                            <th><center scope="col">Alamat</center></th>
                            <th><center scope="col">Tgl Pemeriksaan</center></th>
                            <th><center scope="col">Status</center></th>
                            <th><center scope="col">Action</center></th>
                          </tr>
                        </thead>
                        <tbody>
                          <?php

                          foreach ($formpc_ditangguhkan as $f) : ?>
                          <tr>
                            <td></td>
                              <td><?= $f->nik ?></td>
                              <td><center><?= $f->nama ?></center></td>
                              <td><center><?= $f->alamat ?></center></td>
                              <td><center><?= $f->tgl_periksa ?></center></td>
                              <td><?= $f->status_pemeriksaan ?></td>
                              <td>
                                   
                                   <?php if($f->status_pemeriksaan == 'Belum diajukan') {?>
                                    <a href="<?= base_url(); ?>ABP/editpc/<?= $f->id ?>" class="badge badge-success">Edit</a>
                                   <?php } else {?>
                                     <a  href="javascript:void(0);" class="badge badge-secondary">Edit</a>
                                   <?php }?>
                                

                                  <a href="<?= base_url(); ?>ABP/detailpc/<?= $f->id ?>"
                                    class="badge badge-info">Detail</a>

                                   <?php if($f->status_pemeriksaan == 'Belum diajukan') {?>
                                    <a href="<?= base_url(); ?>ABP/ajukanpc/<?= $f->id ?>" class="badge badge-warning" onclick="return confirm('Apa anda yakin ingin mengajukan?')">Ajukan</a>
                                   <?php } else {?>
                                     <a  href="javascript:void(0);" class="badge badge-secondary">Ajukan</a>
                                   <?php }?>
                                   
                                      <a href="<?= base_url(); ?>ABP/formrab?id=<?= $f->id ?>" class="badge badge-primary">RAB
                                    </a> 
                                       
                                    <?php if($f->status_pemeriksaan == 'Belum diajukan') {?>
                                         <a href="<?= base_url(); ?>ABP/deletepc/<?= $f->id ?>" class="badge badge-danger" onclick="return confirm('Apa anda yakin ingin menghapus data?')">Delete</a>
                                   <?php } else {?>
                                     <a  href="javascript:void(0);" class="badge badge-secondary">Delete</a>
                                   <?php }?>
                                      </td>

                                    </tr>
                                  <?php endforeach ; ?>
                              </tbody>
                            </table>
               </div>
            </div>
       
         </div>
       </div>
  </div>
</div>
      
      <script>
         var t = $('#tabel-semua').DataTable( {
              "columnDefs": [ {
                  "searchable": false,
                  "orderable": false,
                  "targets": 0
              } ],
              "order": [[ 1, 'asc' ]]
          } );
          
          var t2 = $('#tabel-belum-validasi').DataTable( {
              "columnDefs": [ {
                  "searchable": false,
                  "orderable": false,
                  "targets": 0
              } ],
              "order": [[ 1, 'asc' ]]
          } );
          
          var t3 = $('#tabel-valid').DataTable( {
              "columnDefs": [ {
                  "searchable": false,
                  "orderable": false,
                  "targets": 0
              } ],
              "order": [[ 1, 'asc' ]]
          } );
       
         var t4 = $('#tabel-ditangguhkan').DataTable( {
              "columnDefs": [ {
                  "searchable": false,
                  "orderable": false,
                  "targets": 0
              } ],
              "order": [[ 1, 'asc' ]]
          } );
          
          
          t.on( 'order.dt search.dt', function () {
              t.column(0, {search:'applied', order:'applied'}).nodes().each( function (cell, i) {
                  cell.innerHTML = i+1+".";
              } );
          } ).draw();
          
          t2.on( 'order.dt search.dt', function () {
              t.column(0, {search:'applied', order:'applied'}).nodes().each( function (cell, i) {
                  cell.innerHTML = i+1+".";
              } );
          } ).draw();
          
          t3.on( 'order.dt search.dt', function () {
              t.column(0, {search:'applied', order:'applied'}).nodes().each( function (cell, i) {
                  cell.innerHTML = i+1+".";
              } );
          } ).draw();
          
          t4.on( 'order.dt search.dt', function () {
              t.column(0, {search:'applied', order:'applied'}).nodes().each( function (cell, i) {
                  cell.innerHTML = i+1+".";
              } );
          } ).draw();
      </script>
      
      </html>

<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <!-- Custom fonts for this template-->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

  <!-- Custom styles for this template-->
  <link href="css/sb-admin-2.min.css" rel="stylesheet">
</head>

<body>
  <div class="container-fluid">
    <div class="row">
      <div class="col-sm-7">

        <div class="card border-light">
          <div class="card-header">Data Calon Penerima Bantuan</div>
          <div class="card-body text-dark">
            <form>
              <div class="form-group row">
                <label for="nik" class="col-sm-4 col-form-label">NIK</label>
                <div class="col-sm-8">
                  <input type="text" class="form-control" id="nik" name="nik" value="<?= $formpc ['nik']; ?>" readonly>
                </div>
              </div>

              <div class="form-group row">
                <label for="nokk" class="col-sm-4 col-form-label">NO KK</label>
                <div class="col-sm-8">
                  <input type="text" class="form-control" id="nokk" name="nokk" value="<?= $formpc ['nokk']; ?>" readonly>
                </div>
              </div>

              <div class="form-group row">
                <label for="nama" class="col-sm-4 col-form-label">Nama Lengkap</label>
                <div class="col-sm-8">
                  <input type="text" class="form-control" id="nama" name="nama" value="<?= $formpc ['nama']; ?>" readonly>
                </div>
              </div>

              <div class="form-group row">
                <label for="sex" class="col-sm-4 col-form-label">Jenis Kelamin</label>
                <div class="col-sm-8">
                  <input type="text" class="form-control" id="sex" name="sex" value="<?= $formpc ['sex']; ?>" readonly>
                </div>
              </div>

              <div class="form-group row">
                <label for="pekerjaan" class="col-sm-4 col-form-label">Pekerjaan</label>
                <div class="col-sm-8">
                  <input type="text" class="form-control" id="pekerjaan" name="pekerjaan" value="<?= $formpc ['pekerjaan']; ?>" readonly>
                </div>
              </div>

              <div class="form-group row">
                <label for="alamat" class="col-sm-4 col-form-label">Alamat</label>
                <div class="col-sm-8">
                  <input type="text" class="form-control" id="alamat" name="alamt" value="<?= $formpc ['alamat']; ?>" readonly>
                </div>
              </div>

              <div class="form-group row">
                <label for="kelurahan" class="col-sm-4 col-form-label">Kelurahan</label>
                <div class="col-sm-8">
                  <input type="text" class="form-control" id="kelurahan" name="kelurahan" value="<?= $formpc ['kelurahan']; ?>" readonly>
                </div>
              </div>

              <div class="form-group row">
                <label for="kecamatan" class="col-sm-4 col-form-label">Kecamatan</label>
                <div class="col-sm-8">
                  <input type="text" class="form-control" id="kecamatan" name="kecamatan" value="<?= $formpc ['kecamatan']; ?>" readonly>
                </div>
              </div>

              <div class="form-group row">
                <label for="bantuan" class="col-sm-4 col-form-label">Jenis Bantuan</label>
                <div class="col-sm-8">
                  <input type="text" class="form-control" id="bantuan" name="bantuan" value="<?= $formpc ['bantuan']; ?>" readonly>
                </div>
              </div>

              <div class="form-group row">
                <label for="rusak" class="col-sm-4 col-form-label">Kategori Kerusakan</label>
                <div class="col-sm-8">
                  <input type="text" class="form-control" id="rusak" name="rusak" value="<?= $formpc ['rusak']; ?>" readonly>
                </div>
              </div>

              <div class="form-group row">
                <label for="status" class="col-sm-4 col-form-label">Status Lahan</label>
                <div class="col-sm-8">
                  <input type="text" class="form-control" id="status" name="status" value="<?= $formpc ['status']; ?>" readonly>
                </div>
              </div>

              <div class="form-group row">
                <label for="name" class="col-sm-4 col-form-label">Nama Asisten Bidang Perencanaan</label>
                <div class="col-sm-8">
                  <input type="text" class="form-control" id="name" name="name" value="<?= $formpc ['name']; ?>" readonly>
                </div>
              </div>

            </form>
          </div>
        </div>
      </div>

      <div class="col-sm-5">
        <div class="card border-light">
          <div class="card-header">Foto</div>
          <div class="card-body text-dark">
            <h5 class="card-title">Dark card title</h5>
            <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
          </div>
        </div>

      </div>
    </div>
  </div>

</body>

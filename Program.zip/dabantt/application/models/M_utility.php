<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_utility extends CI_Model{
  
  function get_data($data, $table, $where=NULL, $limit=NULL){
      $this->db->select($data);
      $this->db->from($table);
      if(isset($where)){
         $this->db->where($where);
      }
      if(isset($limit)){
         $this->db->limit($limit);
      }
      return $this->db->get();
  }
  
  function get_data_where_in($data, $tabel, $column_name, $array_qualification, $limit=null, $order_by=null){
     $this->db->select($data);
     $this->db->from($tabel);
     $this->db->where_in($column_name, $array_qualification);
     if(isset($limit)){
	    $this->db->limit($limit);
	  }
	  
  	  if(isset($order_by)){
	    $this->db->order_by($order_by[0], $order_by[1]); //[0] ==> column name, [1] ==> order type (ASC or DESC) 
	  }
     return $this->db->get();        
 }
  
  function insert_data($data, $table){
       $this->db->insert($table, $data);
   }
   
   function edit($table, $where, $data){
        $this->db->update($table, $data, $where);
        return $this->db->affected_rows();
    }
   
   function delete_data($table, $where){
        $this->db->delete($table, $where);
        return $this->db->affected_rows();
    }
}

?>

<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_user extends CI_Model{
   
   function get_user_profile($id_user){
      $this->db->select("user.id, user.name, user.email, user.nip, user.image, user_role.role");
      $this->db->from('user');
      $this->db->join('user_role', 'user.role_id = user_role.id');
      $this->db->where('user.id', $id_user);
      $this->db->limit(1);
      return $this->db->get();
   }
   
   function get_user_active($where = NULL){
      $this->db->select('user.id, user.nip, user.name, user.image, user.email, user.role_id, user_role.role');
      $this->db->from('user');
      $this->db->join('user_role', 'user.role_id = user_role.id');
      $this->db->where('is_active', 1);
      if(isset($where)){
         $this->db->where($where);
      }
      $this->db->order_by('name');
      return $this->db->get();
   }
   
   function get_sebaran_penerima(){
      $this->db->select('COUNT(formpc.kelurahan) AS jumlah, formpc.kelurahan');
      $this->db->from('formpc');
      $this->db->where('status_pemeriksaan', 'Sudah menerima bantuan');
      $this->db->group_by('formpc.kelurahan');
      return $this->db->get();
   }

}

?>

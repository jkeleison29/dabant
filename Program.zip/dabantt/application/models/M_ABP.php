<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_ABP extends CI_Model{

  public function get_profile_rab($id){
      $this->db->select('id, nik, nama, status_pemeriksaan');
      $this->db->from('formpc');
      $this->db->where('id', $id);
      $this->db->limit(1);
      return $this->db->get();
  }

  public function get_formpc($where){
      $this->db->select('id, nama, nik, alamat, status_pemeriksaan, catatan, keterangan_pemeriksaan as keterangan, tgl_periksa');
      $this->db->from('formpc');
      $this->db->where($where);
      $this->db->group_by('formpc.id');
      return $this->db->get();
  }

  public function getCalonPB()
	{
  	$query = $this->db->get_where('formpc',array('status_pemeriksaan'=>'Belum diajukan'));
		$query->result_array();
	}

  public function insert($data)
  {

    $this->db->insert('formpc', $data);
  }

  public function getFormpcById($id)
  {
    return $this->db->get_where('formpc', ['id' => $id])->row_array();
  }

  public function edit($data)
  {
    $this->db->where('id', $this->input->post('id'));
    $this->db->update('formpc', $data);
  }

  public function detail($id)
  { $where=array(
    'id'=> $id);
    return $this->db->get_where('formpc',$where)->row_array();
  }

  public function delete($id)
  {
    $this->db->where('id', $id);
    $this->db->delete('formpc');
  }

  public function update_status($id)
    {
    $sql= $this->db->query("UPDATE formpc SET status_pemeriksaan = 'Tahap Validasi' WHERE id = $id");
		return $sql;
  }

  public function getFormpc($keyword = null)
  {
    if($keyword)
    {
      $this->db->like('nik', $keyword);
    }
    return $this->db->get('formpc', $keyword)->result_array();
  }

  public function upload_file($id, $filename, $post, $config){
		$file_ext = pathinfo($filename,PATHINFO_EXTENSION);
		$new_name = $id.'-'.time().'-'.$post.'.'.$file_ext;
		$config['file_name'] = $new_name;

		$this->load->library('upload', $config, $post);
		$this->$post->initialize($config);
		if($this->$post->do_upload($post)){
			return $new_name;
		} else {
			// $this->session->set_flashdata( 'upload_error', '<div class="alert alert-danger" role="alert">'.$this->$post->display_errors().'-----------------'.$config['upload_path'].'</div>');
			// $this->session->set_flashdata( 'upload_error', '<div class="alert alert-danger" role="alert">Perhatikan Ukuran(Maks 2MB) atau Tipe File(JPG,PNG,PDF)!</div>');
			// $this->session->set_flashdata( 'upload_error', '<div class="alert alert-danger" role="alert">Lengkapi dan Perhatikan Ukuran/Tipe File!</div>');
			// return false;
			return "default.jpg";
		}
	}

}
